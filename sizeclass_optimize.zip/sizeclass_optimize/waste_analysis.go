// waste_analysis - Detailed per-class waste analysis with visual charts.
//
// Usage: go run waste_analysis.go [sizeclass_file]
//   Default: go_8page_unit
//
// Output:
//   Terminal: full report with charts
//   <config>_analysis.txt  — full text report
//   <config>_analysis.csv  — per-class data for spreadsheet/charting
//   <config>_summary.csv   — summary row

package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

const (
	pageSize    = 8192
	maxBarWidth = 60
)

type SizeClass struct {
	Index      int
	ClassSize  int
	NPages     int
	SpanSize   int
	ObjPerSpan int
}

type DataRow struct {
	DataSize        int
	CountScan       int64
	CountNoscan     int64
	TotalCount      int64
	TotalSizeBytes  int64
	ElemSize        int
	TotalSizeAlign8 int64
}

type ClassWaste struct {
	Class               SizeClass
	MinSize             int
	MaxSize             int
	SizesCount          int
	ScanCount           int64
	NoscanCount         int64
	TotalCount          int64
	InternalWaste       int64
	ScanSpans           int64
	NoscanSpans         int64
	ScanSpanBytes       int64
	NoscanSpanBytes     int64
	ScanExternalWaste   int64
	NoscanExternalWaste int64
	TotalAllocBytes     int64
	TotalWaste          int64
	ObjBytesSum         int64
}

func main() {
	classFile := "go_8page_unit"
	dataFile := "datasize.txt"
	outDir := "."
	if len(os.Args) > 1 {
		classFile = os.Args[1]
	}
	if len(os.Args) > 2 {
		dataFile = os.Args[2]
	}

	// Output files go to the data file's directory
	if dir := filepath.Dir(dataFile); dir != "." {
		outDir = dir
	}

	classes := parseSizeClasses(classFile)
	rows := parseData(dataFile)

	wastes := computeWaste(classes, rows)

	// Determine base name for output files
	baseName := filepath.Base(classFile)
	baseName = strings.TrimSuffix(baseName, filepath.Ext(baseName))

	// Terminal output
	printMethodology(os.Stdout)
	printPerClassTable(os.Stdout, wastes)
	printCharts(os.Stdout, wastes)
	printWorstOffenders(os.Stdout, wastes)
	printSummary(os.Stdout, wastes, rows)

	// Write report file
	reportPath := filepath.Join(outDir, baseName+"_analysis.txt")
	rf, err := os.Create(reportPath)
	if err == nil {
		printMethodology(rf)
		printPerClassTable(rf, wastes)
		printCharts(rf, wastes)
		printWorstOffenders(rf, wastes)
		printSummary(rf, wastes, rows)
		rf.Close()
		fmt.Printf("\nReport saved to: %s\n", reportPath)
	}

	// Write CSV
	csvPath := filepath.Join(outDir, baseName+"_analysis.csv")
	writeCSV(csvPath, wastes)
	fmt.Printf("CSV saved to: %s\n", csvPath)

	// Write summary CSV
	summaryPath := filepath.Join(outDir, baseName+"_summary.csv")
	writeSummaryCSV(summaryPath, wastes, rows)
	fmt.Printf("Summary CSV saved to: %s\n", summaryPath)
}

func parseSizeClasses(filename string) []SizeClass {
	f, _ := os.Open(filename)
	defer f.Close()
	var classes []SizeClass
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "-") {
			continue
		}
		parts := strings.Split(line, ",")
		if len(parts) != 2 {
			continue
		}
		size, _ := strconv.Atoi(strings.TrimSpace(parts[0]))
		npages, _ := strconv.Atoi(strings.TrimSpace(parts[1]))
		spanSize := npages * pageSize
		objPerSpan := 0
		if size > 0 {
			objPerSpan = spanSize / size
		}
		classes = append(classes, SizeClass{
			Index:      len(classes),
			ClassSize:  size,
			NPages:     npages,
			SpanSize:   spanSize,
			ObjPerSpan: objPerSpan,
		})
	}
	return classes
}

func parseData(filename string) []DataRow {
	f, _ := os.Open(filename)
	defer f.Close()
	var rows []DataRow
	sc := bufio.NewScanner(f)
	header := false
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "totalSize=") {
			continue
		}
		if !header {
			header = true
			continue
		}
		parts := strings.Split(line, "\t")
		if len(parts) < 6 {
			continue
		}
		ds, _ := strconv.Atoi(strings.TrimSpace(parts[0]))
		cs, _ := strconv.ParseInt(strings.TrimSpace(parts[1]), 10, 64)
		cn, _ := strconv.ParseInt(strings.TrimSpace(parts[2]), 10, 64)
		ts, _ := strconv.ParseInt(strings.TrimSpace(parts[3]), 10, 64)
		es, _ := strconv.Atoi(strings.TrimSpace(parts[4]))
		ta, _ := strconv.ParseInt(strings.TrimSpace(parts[5]), 10, 64)
		rows = append(rows, DataRow{ds, cs, cn, cs + cn, ts, es, ta})
	}
	return rows
}

func findClass(size int, classes []SizeClass) *SizeClass {
	for i := 1; i < len(classes); i++ {
		if classes[i].ClassSize >= size {
			return &classes[i]
		}
	}
	return &classes[len(classes)-1]
}

func computeWaste(classes []SizeClass, rows []DataRow) []ClassWaste {
	result := make(map[int]*ClassWaste)
	for i := 1; i < len(classes); i++ {
		result[i] = &ClassWaste{
			Class:   classes[i],
			MinSize: 999999,
		}
	}

	for _, r := range rows {
		if r.TotalCount == 0 {
			continue
		}
		sc := findClass(r.DataSize, classes)
		if sc == nil || sc.Index == 0 {
			continue
		}
		cw := result[sc.Index]
		cw.ScanCount += r.CountScan
		cw.NoscanCount += r.CountNoscan
		cw.TotalCount += r.TotalCount
		cw.SizesCount++
		cw.ObjBytesSum += r.TotalSizeBytes
		if r.DataSize < cw.MinSize {
			cw.MinSize = r.DataSize
		}
		if r.DataSize > cw.MaxSize {
			cw.MaxSize = r.DataSize
		}
		if r.CountScan > 0 {
			cw.InternalWaste += int64(sc.ClassSize-r.DataSize) * r.CountScan
		}
		if r.CountNoscan > 0 {
			cw.InternalWaste += int64(sc.ClassSize-r.DataSize) * r.CountNoscan
		}
	}

	for _, cw := range result {
		c := cw.Class
		if c.ObjPerSpan == 0 {
			continue
		}
		if cw.ScanCount > 0 {
			cw.ScanSpans = (cw.ScanCount + int64(c.ObjPerSpan) - 1) / int64(c.ObjPerSpan)
			cw.ScanSpanBytes = cw.ScanSpans * int64(c.SpanSize)
			cw.ScanExternalWaste = cw.ScanSpanBytes - cw.ScanCount*int64(c.ClassSize)
		}
		if cw.NoscanCount > 0 {
			cw.NoscanSpans = (cw.NoscanCount + int64(c.ObjPerSpan) - 1) / int64(c.ObjPerSpan)
			cw.NoscanSpanBytes = cw.NoscanSpans * int64(c.SpanSize)
			cw.NoscanExternalWaste = cw.NoscanSpanBytes - cw.NoscanCount*int64(c.ClassSize)
		}
		cw.TotalAllocBytes = cw.ScanSpanBytes + cw.NoscanSpanBytes
		cw.TotalWaste = cw.InternalWaste + cw.ScanExternalWaste + cw.NoscanExternalWaste
	}

	var sorted []ClassWaste
	for i := 1; i < len(classes); i++ {
		if cw, ok := result[i]; ok && cw.TotalCount > 0 {
			sorted = append(sorted, *cw)
		}
	}
	return sorted
}

func printMethodology(w io.Writer) {
	fmt.Fprintln(w, strings.Repeat("━", 90))
	fmt.Fprintln(w, "  浪费计算模型")
	fmt.Fprintln(w, strings.Repeat("━", 90))

	fmt.Fprint(w, `
  输入:
    - 业务对象分配数据 (datasize.txt): 每种 size 的对象数量 (scan/noscan)
    - Size class 配置: 每个 class 的 (classSize, npages)

  映射规则:
    对象 size s → 最小 classSize ≥ s 的 class

  两类浪费:

  ┌─ 内部碎片 (Internal Waste) ─────────────────────────────────┐
  │ 每个对象被向上取整到 classSize，多占的空间白费。              │
  │                                                              │
  │   internalWaste = Σ (classSize - actualSize) × objectCount   │
  │                                                              │
  │  例: 3字节对象 → class 8, 每对象浪费 5 字节                     │
  └──────────────────────────────────────────────────────────────┘

  ┌─ 外部碎片 (External Waste) ─────────────────────────────────┐
  │ span 尾部填不满一个完整对象的剩余空间。                       │
  │ scan 和 noscan 对象分属不同 mcentral，span 独立计算。         │
  │                                                              │
  │   spanSize      = npages × 8192                              │
  │   objPerSpan    = spanSize / classSize                       │
  │   spans         = ceil(objectCount / objPerSpan)             │
  │   externalWaste = spans × spanSize - objectCount × classSize │
  │                                                              │
  │  例: class 24, np=8, span=64KB, objPerSpan=2730                 │
  │      2730个对象恰好填满2730×24=65520B, 剩余65536-65520=16B       │
  └──────────────────────────────────────────────────────────────┘

  总浪费 = 内部碎片 + 外部碎片(scan) + 外部碎片(noscan)
`)
}

func formatBytes(b int64) string {
	if b < 1024 {
		return fmt.Sprintf("%d B", b)
	} else if b < 1024*1024 {
		return fmt.Sprintf("%.1f KB", float64(b)/1024)
	} else if b < 1024*1024*1024 {
		return fmt.Sprintf("%.1f MB", float64(b)/(1024*1024))
	}
	return fmt.Sprintf("%.2f GB", float64(b)/(1024*1024*1024))
}

func bar(width int, maxWidth int) string {
	if maxWidth == 0 {
		maxWidth = 1
	}
	n := width * maxBarWidth / maxWidth
	if n == 0 && width > 0 {
		n = 1
	}
	return strings.Repeat("█", n)
}

func printPerClassTable(w io.Writer, wastes []ClassWaste) {
	fmt.Fprintln(w, strings.Repeat("━", 130))
	fmt.Fprintln(w, "  每个 Class 的浪费详情 (按 classSize 排序)")
	fmt.Fprintln(w, strings.Repeat("━", 130))

	fmt.Fprintf(w, "%-4s %-8s %-5s %-6s %-6s %-12s %-12s %-14s %-14s %-14s\n",
		"Idx", "Size", "nPgs", "O/S", "Sizes",
		"TotalObj", "ObjBytes",
		"IntWaste", "ExtWaste", "TotalWaste")
	fmt.Fprintln(w, strings.Repeat("─", 130))

	for _, cw := range wastes {
		c := cw.Class
		extW := cw.ScanExternalWaste + cw.NoscanExternalWaste
		fmt.Fprintf(w, "%-4d %-8d %-5d %-6d %-6d %-12d %-12s %-14s %-14s %-14s\n",
			c.Index, c.ClassSize, c.NPages, c.ObjPerSpan, cw.SizesCount,
			cw.TotalCount, formatBytes(cw.ObjBytesSum),
			formatBytes(cw.InternalWaste),
			formatBytes(extW),
			formatBytes(cw.TotalWaste))
	}
	fmt.Fprintln(w, strings.Repeat("─", 130))
}

func printCharts(w io.Writer, wastes []ClassWaste) {
	var maxIW, maxEW, maxTW int64
	for _, cw := range wastes {
		extW := cw.ScanExternalWaste + cw.NoscanExternalWaste
		if cw.InternalWaste > maxIW {
			maxIW = cw.InternalWaste
		}
		if extW > maxEW {
			maxEW = extW
		}
		if cw.TotalWaste > maxTW {
			maxTW = cw.TotalWaste
		}
	}

	sorted := make([]ClassWaste, len(wastes))
	copy(sorted, wastes)
	sort.Slice(sorted, func(i, j int) bool {
		return sorted[i].TotalWaste > sorted[j].TotalWaste
	})

	fmt.Fprintln(w)
	fmt.Fprintln(w, strings.Repeat("━", 130))
	fmt.Fprintln(w, "  内部碎片分布 (按浪费量降序，top 30)")
	fmt.Fprintln(w, strings.Repeat("━", 130))
	fmt.Fprintf(w, "%-6s %-8s %-12s %-14s %s\n", "Size", "ObjCnt", "IntWaste", "占比", "")
	fmt.Fprintln(w, strings.Repeat("─", 100))
	for i, cw := range sorted {
		if i >= 30 {
			break
		}
		if cw.InternalWaste == 0 {
			continue
		}
		pct := float64(cw.InternalWaste) / float64(maxIW) * 100
		fmt.Fprintf(w, "%-6d %-8d %-12s %-13.1f%% %s\n",
			cw.Class.ClassSize, cw.TotalCount,
			formatBytes(cw.InternalWaste),
			pct, bar(int(cw.InternalWaste), int(maxIW)))
	}
	fmt.Fprintln(w, strings.Repeat("─", 100))

	fmt.Fprintln(w)
	fmt.Fprintln(w, strings.Repeat("━", 130))
	fmt.Fprintln(w, "  外部碎片分布 (按浪费量降序)")
	fmt.Fprintln(w, strings.Repeat("━", 130))
	fmt.Fprintf(w, "%-6s %-8s %-12s %-14s %s\n", "Size", "ObjCnt", "ExtWaste", "占比", "")
	fmt.Fprintln(w, strings.Repeat("─", 100))
	for i, cw := range sorted {
		extW := cw.ScanExternalWaste + cw.NoscanExternalWaste
		if i >= 30 || extW == 0 {
			break
		}
		pct := float64(extW) / float64(maxEW) * 100
		fmt.Fprintf(w, "%-6d %-8d %-12s %-13.1f%% %s\n",
			cw.Class.ClassSize, cw.TotalCount,
			formatBytes(extW),
			pct, bar(int(extW), int(maxEW)))
	}
	fmt.Fprintln(w, strings.Repeat("─", 100))

	fmt.Fprintln(w)
	fmt.Fprintln(w, strings.Repeat("━", 130))
	fmt.Fprintln(w, "  总浪费分布 (内部+外部，降序 top 30)")
	fmt.Fprintln(w, strings.Repeat("━", 130))
	fmt.Fprintf(w, "%-6s %-8s %-12s %-14s %s\n", "Size", "ObjCnt", "TotWaste", "占比", "")
	fmt.Fprintln(w, strings.Repeat("─", 100))
	for i, cw := range sorted {
		if i >= 30 {
			break
		}
		pct := float64(cw.TotalWaste) / float64(maxTW) * 100
		fmt.Fprintf(w, "%-6d %-8d %-12s %-13.1f%% %s\n",
			cw.Class.ClassSize, cw.TotalCount,
			formatBytes(cw.TotalWaste),
			pct, bar(int(cw.TotalWaste), int(maxTW)))
	}
	fmt.Fprintln(w, strings.Repeat("─", 100))
}

func printWorstOffenders(w io.Writer, wastes []ClassWaste) {
	sorted := make([]ClassWaste, len(wastes))
	copy(sorted, wastes)
	sort.Slice(sorted, func(i, j int) bool {
		wi := float64(sorted[i].TotalWaste) / float64(sorted[i].TotalCount)
		wj := float64(sorted[j].TotalWaste) / float64(sorted[j].TotalCount)
		return wi > wj
	})

	fmt.Fprintln(w)
	fmt.Fprintln(w, strings.Repeat("━", 130))
	fmt.Fprintln(w, "  浪费热力图 — 每对象浪费最多的 class (top 20)")
	fmt.Fprintln(w, strings.Repeat("━", 130))
	fmt.Fprintf(w, "%-6s %-8s %-8s %-10s %-10s %-10s %-10s\n",
		"Size", "nPgs", "ObjCnt", "Waste/Obj", "IntW%", "ExtW%", "SizeRange")
	fmt.Fprintln(w, strings.Repeat("─", 110))
	for i, cw := range sorted {
		if i >= 20 {
			break
		}
		if cw.TotalCount == 0 || cw.TotalWaste == 0 {
			continue
		}
		wastePerObj := float64(cw.TotalWaste) / float64(cw.TotalCount)
		iwPct := float64(cw.InternalWaste) / float64(cw.TotalWaste) * 100
		extW := cw.ScanExternalWaste + cw.NoscanExternalWaste
		ewPct := float64(extW) / float64(cw.TotalWaste) * 100
		fmt.Fprintf(w, "%-6d %-8d %-8d %-10.1f %-9.0f%% %-9.0f%% [%d-%d]\n",
			cw.Class.ClassSize, cw.Class.NPages, cw.TotalCount,
			wastePerObj, iwPct, ewPct,
			cw.MinSize, cw.MaxSize)
	}
	fmt.Fprintln(w, strings.Repeat("─", 110))

	fmt.Fprintln(w)
	fmt.Fprintln(w, "  内部碎片率最高的 class (classSize / minSize 比值大, top 10):")
	fmt.Fprintf(w, "%-6s %-8s %-8s %-10s %-12s %s\n",
		"Size", "MinSize", "MaxSize", "Ratio", "IntW(MB)", "ObjCnt")
	fmt.Fprintln(w, strings.Repeat("─", 80))
	sort.Slice(sorted, func(i, j int) bool {
		ri := float64(sorted[i].Class.ClassSize) / float64(sorted[i].MinSize)
		rj := float64(sorted[j].Class.ClassSize) / float64(sorted[j].MinSize)
		return ri > rj
	})
	for i, cw := range sorted {
		if i >= 10 {
			break
		}
		if cw.MinSize == 0 {
			continue
		}
		ratio := float64(cw.Class.ClassSize) / float64(cw.MinSize)
		fmt.Fprintf(w, "%-6d %-8d %-8d %-10.1fx %-12s %d\n",
			cw.Class.ClassSize, cw.MinSize, cw.MaxSize,
			ratio, formatBytes(cw.InternalWaste), cw.TotalCount)
	}
}

func printSummary(w io.Writer, wastes []ClassWaste, rows []DataRow) {
	var totalIW, totalEW, totalSpanBytes, totalObj int64
	for _, cw := range wastes {
		totalIW += cw.InternalWaste
		totalEW += cw.ScanExternalWaste + cw.NoscanExternalWaste
		totalSpanBytes += cw.TotalAllocBytes
		totalObj += cw.TotalCount
	}
	totalWaste := totalIW + totalEW

	var totalActual int64
	for _, r := range rows {
		totalActual += r.TotalSizeBytes
	}

	fmt.Fprintln(w)
	fmt.Fprintln(w, strings.Repeat("━", 90))
	fmt.Fprintln(w, "  最终汇总")
	fmt.Fprintln(w, strings.Repeat("━", 90))
	fmt.Fprintf(w, "  Class 数量:                 %d\n", len(wastes))
	fmt.Fprintf(w, "  总对象数:                   %d\n", totalObj)
	fmt.Fprintf(w, "  对象实际字节 (无损):        %s (%.2f MB)\n",
		formatBytes(totalActual), float64(totalActual)/(1024*1024))
	fmt.Fprintf(w, "  Span 总分配字节:             %s (%.2f MB)\n",
		formatBytes(totalSpanBytes), float64(totalSpanBytes)/(1024*1024))
	fmt.Fprintln(w, "  ─────────────────────────────────────────")
	fmt.Fprintf(w, "  内部碎片:                   %s (%.2f MB)\n",
		formatBytes(totalIW), float64(totalIW)/(1024*1024))
	fmt.Fprintf(w, "  外部碎片:                   %s (%.2f MB)\n",
		formatBytes(totalEW), float64(totalEW)/(1024*1024))
	fmt.Fprintf(w, "  总浪费:                     %s (%.2f MB)\n",
		formatBytes(totalWaste), float64(totalWaste)/(1024*1024))
	fmt.Fprintln(w, "  ─────────────────────────────────────────")
	fmt.Fprintf(w, "  内存效率:                   %.2f%%\n",
		float64(totalActual)/float64(totalSpanBytes)*100)
	fmt.Fprintf(w, "  浪费率:                     %.2f%%\n",
		float64(totalWaste)/float64(totalSpanBytes)*100)
	fmt.Fprintf(w, "  内部/外部碎片比:              %.1f : 1\n",
		float64(totalIW)/float64(totalEW))
	fmt.Fprintln(w, strings.Repeat("━", 90))
}

// writeCSV writes per-class waste data as CSV.
func writeCSV(path string, wastes []ClassWaste) {
	f, err := os.Create(path)
	if err != nil {
		return
	}
	defer f.Close()

	f.WriteString("Index,ClassSize,NPages,SpanSize,ObjPerSpan,SizesCount," +
		"ScanCount,NoscanCount,TotalCount,ObjBytes," +
		"ScanSpans,NoscanSpans,ScanSpanBytes,NoscanSpanBytes," +
		"ScanExternalWaste,NoscanExternalWaste," +
		"InternalWaste,ExternalWaste,TotalWaste," +
		"MinSize,MaxSize\n")

	for _, cw := range wastes {
		c := cw.Class
		extW := cw.ScanExternalWaste + cw.NoscanExternalWaste
		fmt.Fprintf(f, "%d,%d,%d,%d,%d,%d,"+
			"%d,%d,%d,%d,"+
			"%d,%d,%d,%d,"+
			"%d,%d,"+
			"%d,%d,%d,"+
			"%d,%d\n",
			c.Index, c.ClassSize, c.NPages, c.SpanSize, c.ObjPerSpan, cw.SizesCount,
			cw.ScanCount, cw.NoscanCount, cw.TotalCount, cw.ObjBytesSum,
			cw.ScanSpans, cw.NoscanSpans, cw.ScanSpanBytes, cw.NoscanSpanBytes,
			cw.ScanExternalWaste, cw.NoscanExternalWaste,
			cw.InternalWaste, extW, cw.TotalWaste,
			cw.MinSize, cw.MaxSize)
	}
}

// writeSummaryCSV writes a single-row summary for easy comparison across configs.
func writeSummaryCSV(path string, wastes []ClassWaste, rows []DataRow) {
	f, err := os.Create(path)
	if err != nil {
		return
	}
	defer f.Close()

	var totalIW, totalScanEW, totalNoscanEW, totalSpanBytes, totalObj int64
	for _, cw := range wastes {
		totalIW += cw.InternalWaste
		totalScanEW += cw.ScanExternalWaste
		totalNoscanEW += cw.NoscanExternalWaste
		totalSpanBytes += cw.TotalAllocBytes
		totalObj += cw.TotalCount
	}
	totalEW := totalScanEW + totalNoscanEW
	totalWaste := totalIW + totalEW

	var totalActual int64
	for _, r := range rows {
		totalActual += r.TotalSizeBytes
	}

	f.WriteString("NumClasses,TotalObjects,ActualBytes,SpanBytes," +
		"InternalWaste,ScanExternalWaste,NoscanExternalWaste,ExternalWaste,TotalWaste," +
		"EfficiencyPct,WastePct,IW_EW_Ratio\n")
	fmt.Fprintf(f, "%d,%d,%d,%d,"+
		"%d,%d,%d,%d,%d,"+
		"%.2f,%.2f,%.1f\n",
		len(wastes), totalObj, totalActual, totalSpanBytes,
		totalIW, totalScanEW, totalNoscanEW, totalEW, totalWaste,
		float64(totalActual)/float64(totalSpanBytes)*100,
		float64(totalWaste)/float64(totalSpanBytes)*100,
		float64(totalIW)/float64(totalEW))
}
