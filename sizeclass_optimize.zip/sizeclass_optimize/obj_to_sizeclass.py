
import csv
import os
from collections import OrderedDict

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ELE_INDEX = 4

def parse_sizeclass(file):
    results = OrderedDict()
    if not os.path.isfile(file):
        print(f"{file} 不存在")
        return results

    last_span = 0
    with open(file, mode="r") as f:
        lines = f.readlines()
        # 跳过前3行
        lines = lines[3:]
        for line in lines:
            parts = line.strip().split("\t")
            parts = list(map(int, parts))
            spansize = parts[ELE_INDEX]
            if spansize not in results:
                results[spansize] = {
                    "scan": 0,
                    "noscan": 0,
                    "total": 0,
                    "totalSize": 0,
                    "wasted": 0,
                    "wasted_ratio": 0.0,
                    "max_wasted_ratio": 0.0,
                }
            results[spansize]["scan"] += parts[1]
            results[spansize]["noscan"] += parts[2]
            results[spansize]["total"] += (parts[2] + parts[1])
            results[spansize]["totalSize"] += parts[3]
            results[spansize]["wasted"] += (spansize - parts[0]) * (parts[2] + parts[1])
            if spansize == parts[0]:
                if results[spansize]["total"] > 0 and spansize > 0:
                    results[spansize]["wasted_ratio"] = results[spansize]["wasted"] / (results[spansize]["total"] * spansize)
                results[spansize]["max_wasted_ratio"] = (spansize - (last_span + 1)) / spansize
                last_span = spansize

    return results


def write_csv(results: OrderedDict, file):
    with open(output_csv_file, mode="w", newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerow(["span", "scan", "noscan", "total", "totalSize", "wasted", "wasted_ratio", "max_wasted_ratio"])
        for key, items in results.items():
            writer.writerow([
                str(key),
                items["scan"],
                items["noscan"],
                items["total"],
                items["totalSize"],
                items["wasted"],
                items["wasted_ratio"],
                items["max_wasted_ratio"]
            ])


def plot_span_analysis(csv_file, output_file='span_analysis.png', figsize=(14, 8), dpi=100):
    """
    绘制span分析图表（堆叠柱状图：总大小 vs 浪费大小 + 浪费率折线）

    参数:
        csv_file: CSV文件路径
        output_file: 输出图片文件路径
        figsize: 图表大小 (宽, 高)
        dpi: 图片分辨率

    返回:
        None
    """
    # 读取CSV数据
    df = pd.read_csv(csv_file)

    # 按span排序
    df = df.sort_values('span')

    # 将 totalSize & wasted 从B转换为MB
    df['totalSize_MB'] = df['totalSize'] / (1024 * 1024)
    df['wasted_MB'] = df['wasted'] / (1024 * 1024)
    # 计算有效大小（总大小 - 浪费大小）
    df['valid_MB'] = df['totalSize_MB'] - df['wasted_MB']

    # 将wasted_ratio转换为百分比
    df['wasted_ratio_percent'] = df['wasted_ratio'] * 100

    # 创建图表
    fig, ax1 = plt.subplots(figsize=figsize, dpi=dpi)

    # 设置x轴数据
    x = np.arange(len(df))
    span_values = df['span'].values

    # 颜色定义
    color_wasted = '#d62728'     # 浪费空间：红色
    color_valid = '#1f77b4'      # 有效空间：蓝色
    color_ratio = '#ff7f0e'      # 浪费率折线：橙色

    # 左侧Y轴 - 堆叠柱状图（下半部分：wasted_MB，上半部分：valid_MB）
    ax1.set_xlabel('Span', fontsize=12, fontweight='bold')
    ax1.set_ylabel('Size (MB)', fontsize=12, fontweight='bold')
    
    # 绘制堆叠柱状图
    bar_wasted = ax1.bar(x, df['wasted_MB'], color=color_wasted, alpha=0.8, label='Wasted Size (MB)')
    bar_valid = ax1.bar(x, df['valid_MB'], bottom=df['wasted_MB'], color=color_valid, alpha=0.7, label='Valid Size (MB)')
    
    ax1.tick_params(axis='y')
    ax1.tick_params(axis='x', rotation=45)

    # 设置x轴刻度为span值
    ax1.set_xticks(x)
    ax1.set_xticklabels(span_values, fontsize=9)

    # 右侧Y轴 - wasted_ratio_percent折线图
    ax2 = ax1.twinx()
    ax2.set_ylabel('Wasted Ratio (%)', color=color_ratio, fontsize=12, fontweight='bold')
    line = ax2.plot(x, df['wasted_ratio_percent'], color=color_ratio, marker='o',
                    linewidth=2, markersize=6, label='Wasted Ratio (%)')
    ax2.tick_params(axis='y', labelcolor=color_ratio)

    # 设置图表标题
    plt.title('Span Analysis: Total Size (MB) vs Wasted Size (MB) vs Wasted Ratio (%)', 
              fontsize=14, fontweight='bold', pad=20)

    # 添加网格
    ax1.grid(True, alpha=0.3, linestyle='--')

    # 合并图例
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left', fontsize=10)

    # 调整布局
    plt.tight_layout()

    # 保存图片
    plt.savefig(output_file, bbox_inches='tight')
    print(f"图表已保存到: {output_file}")

    # 显示图表
    plt.show()

    # 关闭图表
    plt.close()


def plot_span_analysis_enhanced(csv_file, output_file='span_analysis_enhanced.png',
                                figsize=(16, 10), dpi=120):
    """
    增强版绘图函数，包含更多统计信息和标注

    参数:
        csv_file: CSV文件路径
        output_file: 输出图片文件路径
        figsize: 图表大小 (宽, 高)
        dpi: 图片分辨率

    返回:
        None
    """
    # 读取CSV数据
    df = pd.read_csv(csv_file)

    # 按span排序
    df = df.sort_values('span')

    # 将totalSize从B转换为MB
    df['totalSize_MB'] = df['totalSize'] / (1024 * 1024)

    # 将wasted_ratio转换为百分比
    df['wasted_ratio_percent'] = df['wasted_ratio'] * 100

    # 创建图表
    fig, (ax1, ax3) = plt.subplots(2, 1, figsize=figsize, dpi=dpi, height_ratios=[3, 1])

    # ========== 第一个子图：双Y轴图表 ==========
    x = np.arange(len(df))
    span_values = df['span'].values

    # 左侧Y轴 - totalSize_MB柱状图
    color_size = '#2E86AB'
    ax1.set_xlabel('Span', fontsize=12, fontweight='bold')
    ax1.set_ylabel('Total Size (MB)', color=color_size, fontsize=12, fontweight='bold')
    bars = ax1.bar(x, df['totalSize_MB'], color=color_size, alpha=0.8, edgecolor='black', linewidth=0.5)
    ax1.tick_params(axis='y', labelcolor=color_size)
    ax1.tick_params(axis='x', rotation=45)

    # 设置x轴刻度
    ax1.set_xticks(x)
    ax1.set_xticklabels(span_values, fontsize=9)

    # 右侧Y轴 - wasted_ratio_percent折线图
    ax2 = ax1.twinx()
    color_ratio = '#A23B72'
    ax2.set_ylabel('Wasted Ratio (%)', color=color_ratio, fontsize=12, fontweight='bold')
    line = ax2.plot(x, df['wasted_ratio_percent'], color=color_ratio, marker='s',
                    linewidth=2.5, markersize=6, label='Wasted Ratio (%)', alpha=0.9)
    ax2.tick_params(axis='y', labelcolor=color_ratio)

    # 添加最大值和最小值标注
    max_size_idx = df['totalSize_MB'].idxmax()
    max_ratio_idx = df['wasted_ratio_percent'].idxmax()

    ax1.annotate(f'Max Size: {df["totalSize_MB"].max():,.0f} MB',
                 xy=(max_size_idx, df['totalSize_MB'].max()),
                 xytext=(10, 20), textcoords='offset points',
                 arrowprops=dict(arrowstyle='->', color='blue', lw=1.5),
                 fontsize=9, color='blue', fontweight='bold')

    ax2.annotate(f'Max Ratio: {df["wasted_ratio_percent"].max():.2f}%',
                 xy=(max_ratio_idx, df['wasted_ratio_percent'].max()),
                 xytext=(10, -30), textcoords='offset points',
                 arrowprops=dict(arrowstyle='->', color='red', lw=1.5),
                 fontsize=9, color='red', fontweight='bold')

    # ========== 第二个子图：wasted_ratio_percent单独展示 ==========
    ax3.plot(x, df['wasted_ratio_percent'], color='#6B4423', marker='o',
             linewidth=2, markersize=5, alpha=0.8)
    ax3.set_xlabel('Span', fontsize=11, fontweight='bold')
    ax3.set_ylabel('Wasted Ratio (%)', fontsize=11, fontweight='bold')
    ax3.set_xticks(x)
    ax3.set_xticklabels(span_values, rotation=45, fontsize=8)
    ax3.grid(True, alpha=0.3, linestyle='--')
    ax3.set_title('Wasted Ratio (%) Trend', fontsize=12, fontweight='bold', pad=10)

    # 添加水平参考线
    ax3.axhline(y=50, color='red', linestyle='--', alpha=0.5, label='Threshold 50%')
    ax3.axhline(y=100, color='orange', linestyle='--', alpha=0.5, label='Threshold 100%')
    ax3.legend(loc='upper right', fontsize=9)

    # 设置主标题
    fig.suptitle('Span Analysis Dashboard: Total Size (MB) vs Wasted Ratio (%)', fontsize=16, fontweight='bold', y=0.98)

    # 调整子图间距
    plt.subplots_adjust(hspace=0.3)

    # 保存图片
    plt.savefig(output_file, bbox_inches='tight')
    print(f"增强版图表已保存到: {output_file}")

    # 显示图表
    plt.show()

    # 关闭图表
    plt.close()


def plot_span_statistics(csv_file, output_file='span_statistics.png', figsize=(12, 10), dpi=100):
    """
    绘制统计信息图表，包含多个指标

    参数:
        csv_file: CSV文件路径
        output_file: 输出图片文件路径
        figsize: 图表大小 (宽, 高)
        dpi: 图片分辨率

    返回:
        None
    """
    # 读取CSV数据
    df = pd.read_csv(csv_file)

    # 按span排序
    df = df.sort_values('span')

    # 将totalSize从B转换为MB
    df['totalSize_MB'] = df['totalSize'] / (1024 * 1024)

    # 将wasted_ratio转换为百分比
    df['wasted_ratio_percent'] = df['wasted_ratio'] * 100

    # 创建2x2子图
    fig, axes = plt.subplots(2, 2, figsize=figsize, dpi=dpi)
    fig.suptitle('Span Statistics Dashboard', fontsize=16, fontweight='bold')

    x = np.arange(len(df))
    span_values = df['span'].values

    # 图1: Total Size (MB)柱状图
    axes[0, 0].bar(x, df['totalSize_MB'], color='#1f77b4', alpha=0.7)
    axes[0, 0].set_title('Total Size (MB) Distribution', fontweight='bold')
    axes[0, 0].set_xlabel('Span')
    axes[0, 0].set_ylabel('Total Size (MB)')
    axes[0, 0].set_xticks(x[::5])
    axes[0, 0].set_xticklabels(span_values[::5], rotation=45)
    axes[0, 0].grid(True, alpha=0.3)

    # 图2: Wasted Ratio (%)折线图
    axes[0, 1].plot(x, df['wasted_ratio_percent'], color='#ff7f0e', marker='o', linewidth=2)
    axes[0, 1].set_title('Wasted Ratio (%) Trend', fontweight='bold')
    axes[0, 1].set_xlabel('Span')
    axes[0, 1].set_ylabel('Wasted Ratio (%)')
    axes[0, 1].set_xticks(x[::5])
    axes[0, 1].set_xticklabels(span_values[::5], rotation=45)
    axes[0, 1].grid(True, alpha=0.3)
    axes[0, 1].axhline(y=50, color='red', linestyle='--', alpha=0.5)

    # 图3: Total柱状图
    axes[1, 0].bar(x, df['total'], color='#2ca02c', alpha=0.7)
    axes[1, 0].set_title('Total Distribution', fontweight='bold')
    axes[1, 0].set_xlabel('Span')
    axes[1, 0].set_ylabel('Total')
    axes[1, 0].set_xticks(x[::5])
    axes[1, 0].set_xticklabels(span_values[::5], rotation=45)
    axes[1, 0].grid(True, alpha=0.3)

    # 图4: Wasted vs Wasted Ratio (%)散点图
    scatter = axes[1, 1].scatter(df['wasted'], df['wasted_ratio_percent'],
                                 c=df['span'], cmap='viridis', s=50, alpha=0.6)
    axes[1, 1].set_title('Wasted vs Wasted Ratio (%)', fontweight='bold')
    axes[1, 1].set_xlabel('Wasted')
    axes[1, 1].set_ylabel('Wasted Ratio (%)')
    axes[1, 1].grid(True, alpha=0.3)
    plt.colorbar(scatter, ax=axes[1, 1], label='Span')

    # 调整布局
    plt.tight_layout()

    # 保存图片
    plt.savefig(output_file, bbox_inches='tight')
    print(f"统计图表已保存到: {output_file}")

    # 显示图表
    plt.show()

    # 打印详细统计
    print("\n=== 详细统计信息 ===")
    print(f"\nSpan范围: {df['span'].min()} - {df['span'].max()}")
    print(f"记录数: {len(df)}")
    print(f"Total Size (MB) - 平均值: {df['totalSize_MB'].mean():,.2f}")
    print(f"Total Size (MB) - 最大值: {df['totalSize_MB'].max():,.0f} (Span: {df.loc[df['totalSize_MB'].idxmax(), 'span']})")
    print(f"Wasted Ratio (%) - 平均值: {df['wasted_ratio_percent'].mean():.2f}%")
    print(f"Wasted Ratio (%) - 最大值: {df['wasted_ratio_percent'].max():.2f}% (Span: {df.loc[df['wasted_ratio_percent'].idxmax(), 'span']})")

    # 关闭图表
    plt.close()


if __name__ == '__main__':
    new_folder = "./scorebycountaddsize1152"
    datasize_file = f"{new_folder}/datasize06101139.txt"
    output_csv_file = f"{new_folder}/parsed_datasize_new.csv"
    write_csv(parse_sizeclass(datasize_file), output_csv_file)
    plot_span_analysis(output_csv_file, f'{new_folder}/span_analysis_new1.png')
    plot_span_analysis_enhanced(output_csv_file, f'{new_folder}/span_analysis_new2.png')
    plot_span_statistics(output_csv_file, f'{new_folder}/span_analysis_new3.png')
