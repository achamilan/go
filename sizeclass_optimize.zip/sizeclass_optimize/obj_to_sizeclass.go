// obj_to_sizeclass - Go equivalent of obj_to_sizeclass.py
//
// Parses datasize.txt, groups by elemsize (alignment class), computes
// per-class waste statistics, and outputs a CSV report.
//
// Usage: go run obj_to_sizeclass.go

package main

import (
	"bufio"
	"fmt"
	"os"
	"sort"
	"strconv"
	"strings"
)

type SpanStats struct {
	Span           int
	Scan           int64
	Noscan         int64
	Total          int64
	TotalSize      int64
	Wasted         int64
	WastedRatio    float64
	MaxWastedRatio float64
}

func main() {
	// Parse datasize.txt
	results := parseDatasize("datasize.txt")

	// Sort by span
	spans := make([]int, 0, len(results))
	for s := range results {
		spans = append(spans, s)
	}
	sort.Ints(spans)

	// Write CSV
	writeCSV(results, spans, "parsed_datasize.csv")

	// Print summary
	printSummary(results, spans)
}

func parseDatasize(filename string) map[int]*SpanStats {
	f, err := os.Open(filename)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
	defer f.Close()

	results := make(map[int]*SpanStats)
	lastSpan := 0
	header := false
	sc := bufio.NewScanner(f)

	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "totalSize=") {
			continue
		}
		if !header {
			header = true
			continue
		}

		parts := strings.Split(line, "\t")
		if len(parts) < 6 {
			continue
		}

		dataSize, _ := strconv.Atoi(strings.TrimSpace(parts[0]))
		scan, _ := strconv.ParseInt(strings.TrimSpace(parts[1]), 10, 64)
		noscan, _ := strconv.ParseInt(strings.TrimSpace(parts[2]), 10, 64)
		totalSize, _ := strconv.ParseInt(strings.TrimSpace(parts[3]), 10, 64)
		elemSize, _ := strconv.Atoi(strings.TrimSpace(parts[4]))

		if scan+noscan == 0 {
			continue
		}

		spansize := elemSize
		if _, ok := results[spansize]; !ok {
			results[spansize] = &SpanStats{Span: spansize}
		}

		r := results[spansize]
		r.Scan += scan
		r.Noscan += noscan
		r.Total += scan + noscan
		r.TotalSize += totalSize
		r.Wasted += int64(spansize-dataSize) * (scan + noscan)

		if spansize == dataSize {
			if r.Total > 0 && spansize > 0 {
				r.WastedRatio = float64(r.Wasted) / float64(r.Total*int64(spansize))
			}
			r.MaxWastedRatio = float64(spansize-(lastSpan+1)) / float64(spansize)
			lastSpan = spansize
		}
	}
	return results
}

func writeCSV(results map[int]*SpanStats, spans []int, filename string) {
	f, err := os.Create(filename)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error creating %s: %v\n", filename, err)
		return
	}
	defer f.Close()

	f.WriteString("span,scan,noscan,total,totalSize,wasted,wasted_ratio,max_wasted_ratio\n")
	for _, s := range spans {
		r := results[s]
		fmt.Fprintf(f, "%d,%d,%d,%d,%d,%d,%.6f,%.6f\n",
			r.Span, r.Scan, r.Noscan, r.Total, r.TotalSize,
			r.Wasted, r.WastedRatio*100, r.MaxWastedRatio*100)
	}
	fmt.Printf("CSV saved to %s (%d rows)\n", filename, len(spans))
}

func printSummary(results map[int]*SpanStats, spans []int) {
	var totalScan, totalNoscan, totalObj, totalSize, totalWasted int64
	for _, s := range spans {
		r := results[s]
		totalScan += r.Scan
		totalNoscan += r.Noscan
		totalObj += r.Total
		totalSize += r.TotalSize
		totalWasted += r.Wasted
	}

	fmt.Println()
	fmt.Println(strings.Repeat("=", 80))
	fmt.Println("Per-elemsize Waste Summary")
	fmt.Println(strings.Repeat("=", 80))
	fmt.Printf("%-8s %-12s %-12s %-12s %-14s %-14s %-10s %-10s\n",
		"Span", "Scan", "Noscan", "Total", "TotalSize", "Wasted", "Waste%", "MaxWaste%")
	fmt.Println(strings.Repeat("-", 80))

	for _, s := range spans {
		r := results[s]
		fmt.Printf("%-8d %-12d %-12d %-12d %-14d %-14d %-9.2f %-9.2f\n",
			r.Span, r.Scan, r.Noscan, r.Total, r.TotalSize,
			r.Wasted, r.WastedRatio*100, r.MaxWastedRatio*100)
	}

	fmt.Println(strings.Repeat("-", 80))
	fmt.Printf("Total: objects=%d (scan=%d, noscan=%d), size=%d (%.2f MB), wasted=%d (%.2f MB)\n",
		totalObj, totalScan, totalNoscan,
		totalSize, float64(totalSize)/(1024*1024),
		totalWasted, float64(totalWasted)/(1024*1024))
	if totalSize > 0 {
		fmt.Printf("Overall waste ratio: %.2f%%\n", float64(totalWasted)/float64(totalSize)*100)
	}
	fmt.Println(strings.Repeat("=", 80))
}
