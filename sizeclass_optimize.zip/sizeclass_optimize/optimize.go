// optimize - Find optimal size class configuration for given allocation data.
//
// Usage: go run optimize.go
//
// Algorithm:
//   1. Load data and build prefix sums for O(1) waste evaluation
//   2. Start with 2 classes (16 for tiny, 32768 for max)
//   3. Greedy split: each iteration, find the class whose split gives max waste reduction
//   4. Repeat until 67 classes
//   5. Local refinement: shift class boundaries
//   6. Output final configuration
//
// Constraints (matching Go runtime reality):
//   - Class sizes are 8-byte aligned (align8)
//   - First real class = 16 (tiny allocator: objects 1-16 all go here)
//   - Max npages = maxNPages (16, same as round64k experiment limit)
//   - 12.5% waste constraint determines npages via determineNPages (max 16 pages)

package main

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

const (
	pageSize       = 8192
	maxSmallSize   = 32768
	maxSizeClasses = 68
	wasteLimit     = 8   // 12.5% == 1/8
	nPageUnit      = 4   // npages must be multiples of 4 (32KB granularity)
	maxNPageUnits  = 4   // max 4 units = 16 pages = 128KB
	tinyClassSize  = 16  // tiny allocator class
	minAlign       = 8   // minimum alignment
)

type SizeCount struct {
	Size        int
	ScanCount   int64
	NoscanCount int64
	TotalCount  int64
}

type ClassDef struct {
	ClassSize int
	NPages    int
}

type PrefixSums struct {
	ScanCount   []int64
	NoscanCount []int64
	SizeByCount []int64
}

func loadData(filename string) ([]SizeCount, []int) {
	f, err := os.Open(filename)
	if err != nil {
		panic(err)
	}
	defer f.Close()

	countMap := make(map[int]*SizeCount)
	sc := bufio.NewScanner(f)
	header := false
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "totalSize=") {
			continue
		}
		if !header {
			header = true
			continue
		}
		parts := strings.Split(line, "\t")
		if len(parts) < 4 {
			continue
		}
		size, _ := strconv.Atoi(strings.TrimSpace(parts[0]))
		scan, _ := strconv.ParseInt(strings.TrimSpace(parts[1]), 10, 64)
		noscan, _ := strconv.ParseInt(strings.TrimSpace(parts[2]), 10, 64)
		if scan+noscan == 0 {
			continue
		}
		if sc, ok := countMap[size]; ok {
			sc.ScanCount += scan
			sc.NoscanCount += noscan
			sc.TotalCount += scan + noscan
		} else {
			countMap[size] = &SizeCount{
				Size:        size,
				ScanCount:   scan,
				NoscanCount:  noscan,
				TotalCount:  scan + noscan,
			}
		}
	}
	result := make([]SizeCount, 0, len(countMap))
	for _, v := range countMap {
		result = append(result, *v)
	}
	sort.Slice(result, func(i, j int) bool { return result[i].Size < result[j].Size })
	sizes := make([]int, len(result))
	for i, r := range result {
		sizes[i] = r.Size
	}
	return result, sizes
}

func buildPrefixSums(data []SizeCount) PrefixSums {
	n := len(data)
	ps := PrefixSums{
		ScanCount:   make([]int64, n+1),
		NoscanCount: make([]int64, n+1),
		SizeByCount: make([]int64, n+1),
	}
	for i, d := range data {
		ps.ScanCount[i+1] = ps.ScanCount[i] + d.ScanCount
		ps.NoscanCount[i+1] = ps.NoscanCount[i] + d.NoscanCount
		ps.SizeByCount[i+1] = ps.SizeByCount[i] + int64(d.Size)*d.TotalCount
	}
	return ps
}

func align8(sz int) int {
	return (sz + minAlign - 1) &^ (minAlign - 1)
}

// determineNPages returns npages (must be multiple of nPageUnit=8) for a class.
// Uses 12.5% constraint, capped at maxNPageUnits*nPageUnit pages.
// Returns 0 if constraint cannot be satisfied within cap.
func determineNPages(classSize int) int {
	unitSize := nPageUnit * pageSize // 64KB base unit
	maxSize := maxNPageUnits * unitSize
	allocSize := unitSize
	for allocSize%classSize > allocSize/wasteLimit {
		allocSize += unitSize
		if allocSize > maxSize {
			return 0
		}
	}
	return allocSize / pageSize
}

// O(1) waste calculation via prefix sums.
func classWasteFast(ps PrefixSums, start, end int, classSize, npages int) (int64, int64) {
	if start > end {
		return 0, 0
	}
	spanSize := npages * pageSize
	objPerSpan := spanSize / classSize
	if objPerSpan == 0 {
		objPerSpan = 1
	}
	scanCnt := ps.ScanCount[end+1] - ps.ScanCount[start]
	noscanCnt := ps.NoscanCount[end+1] - ps.NoscanCount[start]
	totalCnt := scanCnt + noscanCnt
	totalSizeBytes := ps.SizeByCount[end+1] - ps.SizeByCount[start]

	internalWaste := totalCnt*int64(classSize) - totalSizeBytes

	var externalWaste int64
	if scanCnt > 0 {
		scanSpans := (scanCnt + int64(objPerSpan) - 1) / int64(objPerSpan)
		externalWaste += scanSpans*int64(spanSize) - scanCnt*int64(classSize)
	}
	if noscanCnt > 0 {
		noscanSpans := (noscanCnt + int64(objPerSpan) - 1) / int64(objPerSpan)
		externalWaste += noscanSpans*int64(spanSize) - noscanCnt*int64(classSize)
	}
	return internalWaste, externalWaste
}

func totalClassWaste(ps PrefixSums, start, end int, classSize, npages int) int64 {
	iw, ew := classWasteFast(ps, start, end, classSize, npages)
	return iw + ew
}

func evaluateConfig(ps PrefixSums, sizes []int, classes []ClassDef) (int64, int64, int64) {
	var totalIW, totalEW int64
	start := 0
	n := len(sizes)
	for _, c := range classes {
		if c.ClassSize == 0 {
			continue
		}
		if start >= n {
			break
		}
		end := sort.SearchInts(sizes[start:], c.ClassSize+1) + start - 1
		if end < start {
			continue
		}
		iw, ew := classWasteFast(ps, start, end, c.ClassSize, c.NPages)
		totalIW += iw
		totalEW += ew
		start = end + 1
	}
	return totalIW, totalEW, totalIW + totalEW
}

func formatConfig(classes []ClassDef) string {
	var sb strings.Builder
	sb.WriteString("0,0\n")
	for _, c := range classes {
		if c.ClassSize > 0 {
			sb.WriteString(fmt.Sprintf("%d,%d\n", c.ClassSize, c.NPages))
		}
	}
	return sb.String()
}

func formatCompact(classes []ClassDef) string {
	var parts []string
	for _, c := range classes {
		if c.ClassSize > 0 {
			parts = append(parts, strconv.Itoa(c.ClassSize))
		}
	}
	return strings.Join(parts, ", ")
}

// alignedCandidateSizes returns the set of valid (aligned, maxNPages-satisfiable)
// candidate class sizes from the data. Each candidate must be >= some actual data size.
func alignedCandidateSizes(data []SizeCount) map[int]bool {
	candidates := make(map[int]bool)
	for _, d := range data {
		aligned := align8(d.Size)
		if aligned > maxSmallSize {
			continue
		}
		if determineNPages(aligned) > 0 {
			candidates[aligned] = true
		}
	}
	// Always include required sizes
	candidates[tinyClassSize] = true
	candidates[maxSmallSize] = true
	return candidates
}

func greedySplit(data []SizeCount, sizes []int, ps PrefixSums, target int) []ClassDef {
	classes := []ClassDef{
		{ClassSize: minAlign, NPages: determineNPages(minAlign)},
		{ClassSize: maxSmallSize, NPages: determineNPages(maxSmallSize)},
	}

	iw, ew, tw := evaluateConfig(ps, sizes, classes)
	fmt.Printf("Initial (2 classes: %d, %d): Waste %.2f MB (internal %.2f, external %.2f)\n",
		tinyClassSize, maxSmallSize,
		float64(tw)/(1024*1024), float64(iw)/(1024*1024), float64(ew)/(1024*1024))

	for len(classes) < target {
		bestReduction := int64(-1)
		bestSplitIdx := -1
		bestSplitSize := 0
		bestSplitNP := 0

		start := 0
		for ci, c := range classes {
			if c.ClassSize == 0 {
				continue
			}
			end := sort.SearchInts(sizes[start:], c.ClassSize+1) + start - 1
			if end <= start {
				start = end + 1
				continue
			}

			curWaste := totalClassWaste(ps, start, end, c.ClassSize, c.NPages)

			// Try aligned split points within this class's range
			for mid := start; mid < end; mid++ {
				rawSize := data[mid].Size
				aligned := align8(rawSize)
				if aligned <= 0 || aligned >= c.ClassSize {
					continue
				}

				np1 := determineNPages(aligned)
				if np1 == 0 {
					continue // can't satisfy 12.5% within maxNPages
				}

				// Find the actual end index for the aligned size
				splitEnd := sort.SearchInts(sizes[start:], aligned+1) + start - 1
				if splitEnd < start || splitEnd >= end {
					continue
				}

				w1 := totalClassWaste(ps, start, splitEnd, aligned, np1)
				w2 := totalClassWaste(ps, splitEnd+1, end, c.ClassSize, c.NPages)
				reduction := curWaste - (w1 + w2)
				if reduction > bestReduction {
					bestReduction = reduction
					bestSplitIdx = ci
					bestSplitSize = aligned
					bestSplitNP = np1
				}
			}
			start = end + 1
		}

		if bestSplitIdx < 0 || bestReduction <= 0 {
			fmt.Printf("  No beneficial split at %d classes (reduction=%d). Stopping.\n", len(classes), bestReduction)
			break
		}

		newClasses := make([]ClassDef, 0, len(classes)+1)
		for i, c := range classes {
			if i == bestSplitIdx {
				newClasses = append(newClasses, ClassDef{ClassSize: bestSplitSize, NPages: bestSplitNP})
				newClasses = append(newClasses, c)
			} else {
				newClasses = append(newClasses, c)
			}
		}
		classes = newClasses

		_, _, tw2 := evaluateConfig(ps, sizes, classes)
		if len(classes)%5 == 0 || len(classes) <= 10 {
			fmt.Printf("  %d classes: +%d (np=%d), waste=%.2f MB\n",
				len(classes), bestSplitSize, bestSplitNP, float64(tw2)/(1024*1024))
		}
	}
	return classes
}

// localRefine shifts class boundaries (to aligned values) to reduce waste.
func localRefine(data []SizeCount, sizes []int, ps PrefixSums, classes []ClassDef) []ClassDef {
	type rangeInfo struct{ start, end int }

	for iter := 0; iter < 50; iter++ {
		improved := false

		ranges := make([]rangeInfo, len(classes))
		s := 0
		for i, c := range classes {
			if c.ClassSize == 0 {
				continue
			}
			e := sort.SearchInts(sizes[s:], c.ClassSize+1) + s - 1
			ranges[i] = rangeInfo{s, e}
			s = e + 1
		}

		for i := range classes {
			c := &classes[i]
			ri := ranges[i]
			if ri.start > ri.end || ri.start >= len(data) {
				continue
			}

			curWaste := totalClassWaste(ps, ri.start, ri.end, c.ClassSize, c.NPages)
			bestWaste := curWaste
			bestSize := c.ClassSize
			bestNP := c.NPages

			prevSize := 0
			if i > 0 {
				prevSize = classes[i-1].ClassSize
			}

			// Try candidate aligned sizes within this class's range
			// Only consider actual data sizes that are alignment boundaries
			for j := ri.start; j <= ri.end; j++ {
				ns := align8(data[j].Size)
				if ns <= prevSize || ns >= c.ClassSize {
					continue
				}
				np := determineNPages(ns)
				if np == 0 {
					continue
				}
				splitEnd := sort.SearchInts(sizes[ri.start:], ns+1) + ri.start - 1
				if splitEnd < ri.start || splitEnd >= ri.end {
					continue
				}
				w := totalClassWaste(ps, ri.start, splitEnd, ns, np)
				w += totalClassWaste(ps, splitEnd+1, ri.end, c.ClassSize, c.NPages)
				if w < bestWaste {
					bestWaste = w
					bestSize = ns
					bestNP = np
				}
			}

			if bestSize != c.ClassSize {
				_, _, twOld := evaluateConfig(ps, sizes, classes)
				oldSize := c.ClassSize
				oldNP := c.NPages
				c.ClassSize = bestSize
				c.NPages = bestNP
				_, _, twNew := evaluateConfig(ps, sizes, classes)
				if twNew < twOld {
					improved = true
					fmt.Printf("  Refine[%d] class %d: %d->%d (np %d->%d), waste %.2f->%.2f MB\n",
						iter+1, i, oldSize, bestSize, oldNP, bestNP,
						float64(twOld)/(1024*1024), float64(twNew)/(1024*1024))
					// Recompute ranges
					s2 := 0
					for ii, cc := range classes {
						if cc.ClassSize == 0 {
							continue
						}
						e2 := sort.SearchInts(sizes[s2:], cc.ClassSize+1) + s2 - 1
						ranges[ii] = rangeInfo{s2, e2}
						s2 = e2 + 1
					}
				} else {
					c.ClassSize = oldSize
					c.NPages = oldNP
				}
			}
		}
		if !improved {
			break
		}
	}
	return classes
}

func main() {
	dataFile := "datasize.txt"
	if len(os.Args) > 1 {
		dataFile = os.Args[1]
	}
	outDir := filepath.Dir(dataFile)

	data, sizes := loadData(dataFile)
	ps := buildPrefixSums(data)
	fmt.Printf("Loaded %d unique sizes (range %d-%d)\n", len(data), data[0].Size, data[len(data)-1].Size)
	fmt.Printf("Constraints: align=%d, nPageUnit=%d, maxUnits=%d (max %d pages=%d KB), tinyClass=%d\n\n",
		minAlign, nPageUnit, maxNPageUnits, nPageUnit*maxNPageUnits, nPageUnit*maxNPageUnits*pageSize/1024, tinyClassSize)

	target := maxSizeClasses - 1

	fmt.Println("=== Phase 1: Greedy Split ===")
	classes := greedySplit(data, sizes, ps, target)

	fmt.Println("\n=== Phase 2: Local Refinement ===")
	classes = localRefine(data, sizes, ps, classes)

	iw, ew, tw := evaluateConfig(ps, sizes, classes)

	var totalSpanBytes int64
	start := 0
	for _, c := range classes {
		if c.ClassSize == 0 {
			continue
		}
		if start >= len(sizes) {
			break
		}
		end := sort.SearchInts(sizes[start:], c.ClassSize+1) + start - 1
		if end < start {
			continue
		}
		scanCnt := ps.ScanCount[end+1] - ps.ScanCount[start]
		noscanCnt := ps.NoscanCount[end+1] - ps.NoscanCount[start]
		objPerSpan := c.NPages * pageSize / c.ClassSize
		if objPerSpan == 0 {
			objPerSpan = 1
		}
		if scanCnt > 0 {
			scanSpans := (scanCnt + int64(objPerSpan) - 1) / int64(objPerSpan)
			totalSpanBytes += scanSpans * int64(c.NPages*pageSize)
		}
		if noscanCnt > 0 {
			noscanSpans := (noscanCnt + int64(objPerSpan) - 1) / int64(objPerSpan)
			totalSpanBytes += noscanSpans * int64(c.NPages*pageSize)
		}
		start = end + 1
	}
	totalActual := ps.SizeByCount[len(ps.SizeByCount)-1]

	fmt.Println()
	fmt.Println(strings.Repeat("=", 80))
	fmt.Println("CONSTRAINED OPTIMIZED RESULT")
	fmt.Println(strings.Repeat("=", 80))
	fmt.Printf("Constraints: align8, nPages multiple of %d (max %d), tinyClass=%d\n",
		nPageUnit, nPageUnit*maxNPageUnits, tinyClassSize)
	fmt.Printf("Classes:      %d\n", len(classes))
	fmt.Printf("Actual bytes: %d (%.2f MB)\n", totalActual, float64(totalActual)/(1024*1024))
	fmt.Printf("Span bytes:   %d (%.2f MB)\n", totalSpanBytes, float64(totalSpanBytes)/(1024*1024))
	fmt.Printf("Int waste:    %d (%.2f MB)\n", iw, float64(iw)/(1024*1024))
	fmt.Printf("Ext waste:    %d (%.2f MB)\n", ew, float64(ew)/(1024*1024))
	fmt.Printf("Total waste:  %d (%.2f MB)\n", tw, float64(tw)/(1024*1024))
	fmt.Printf("Waste ratio:  %.2f%%\n", float64(tw)/float64(totalSpanBytes)*100)
	fmt.Printf("Efficiency:   %.2f%%\n", float64(totalActual)/float64(totalSpanBytes)*100)
	fmt.Println()
	fmt.Println("Class sizes:", formatCompact(classes))

	// Also output the full config for waste_calc verification
	fmt.Println()
	fmt.Println("---size class table (size, npages)---")
	configStr := formatConfig(classes)
	fmt.Print(configStr)

	// Save config to file in data directory
	configPath := filepath.Join(outDir, "optimized_config.txt")
	os.WriteFile(configPath, []byte(configStr), 0644)
	fmt.Printf("\nConfig saved to: %s\n", configPath)

	// Save summary
	summaryPath := filepath.Join(outDir, "optimized_summary.txt")
	summary := fmt.Sprintf(
		"Classes: %d\nActualBytes: %d (%.2f MB)\nSpanBytes: %d (%.2f MB)\n"+
			"IntWaste: %d (%.2f MB)\nExtWaste: %d (%.2f MB)\nTotalWaste: %d (%.2f MB)\n"+
			"WasteRatio: %.2f%%\nEfficiency: %.2f%%\n"+
			"ClassSizes: %s\n",
		len(classes), totalActual, float64(totalActual)/(1024*1024),
		totalSpanBytes, float64(totalSpanBytes)/(1024*1024),
		iw, float64(iw)/(1024*1024), ew, float64(ew)/(1024*1024),
		tw, float64(tw)/(1024*1024),
		float64(tw)/float64(totalSpanBytes)*100,
		float64(totalActual)/float64(totalSpanBytes)*100,
		formatCompact(classes))
	os.WriteFile(summaryPath, []byte(summary), 0644)
	fmt.Printf("Summary saved to: %s\n", summaryPath)
}
