#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
根据Go业务进程对象大小分布生成最优的 Go span sizeclass 配置，减少内存浪费，提高内存分配效率

业务对象示例：datasize_20.txt
目标输出文件示例：go_sizeclasses

严格遵守以下规则:
1. 最终 sizeclass 数量必须固定为 68 个 class (0~67),不可增减
2. class 0 固定为 0 字节且页数为0, class 67 固定为 32768 字节(32KB)
   小于1KB的Size默认Pages尽可能为8
3. 区间 & 数量配比:
   - 小对象 (8B~1KB): 不超过55个
   - 中对象 (1KB~8KB): 不超过7个
   - 大对象 (8KB~32KB): ≤5个
   - 禁止全部改为小对象,必须保留大对象规格,控制对象总数,防止GC频率飙升
4. 所有 size,npages满足以下条件:
   pageSize = 8192
   allocsize = pageSize * npages
   规则1: (allocsize % size) ≤ allocsize ÷ 8
   规则2:
       div = allocsize // size
       temp = allocsize // div
       new_size = temp & (~127)
       要求 size ≥ new_size
5. 必须保留 16B 作为 tiny 对象规格,不可删除
6. 划分遵循步长递增原则:
   - 8B~128B 使用 8B 步长
   - 128B~1KB 使用 16B/32B 步长
   - 1KB 以上使用更大步长
7. 优先覆盖业务高频对象大小,自动向上 8 对齐
8. 脚本自带校验逻辑,检查:总数 68、对齐、递增、边界值合法、规则1/2合法
"""

import argparse
import sys
from functools import lru_cache
from pathlib import Path
from typing import List, Tuple, Dict

# ── 全局常量 ─────────────────────────────────────────────
PAGE_SIZE = 8192
TARGET_COUNT = 68
MAX_SMALL_CLASS = 328  # 1KB / 8 * 8 = 1024, boundary for classification

# 区间配比上限（与规则3一致）
ZONE_LIMITS = {
    'small':  55,   # 8B ~ 1KB
    'medium': 7,    # 1KB ~ 8KB
    'large':  5,    # 8KB ~ 32KB
}

# 必须保留的规格
MANDATORY_SMALL = {8, 16, 32, 64, 128, 512}
MANDATORY_LARGE = {32768}

# 步长配置
SMALL_STEP_8B_END  = 128
SMALL_STEP_16B_END = 512
SMALL_STEP_32B_END = 1024
MEDIUM_STEP        = 128
MEDIUM_END         = 8192
LARGE_STEP         = 256
LARGE_END          = 32768

SMALL_SIZE_MAX = 1024
SMALL_SIZE_DIV = 8

MAX_SMALL_SIZE = 32768
LARGE_SIZE_DIV = 128



# ── 数据解析 ─────────────────────────────────────────────

def parse_datasize_file(filepath: str) -> List['SizeDistribution']:
    """解析业务数据文件，自动跳过表头行"""
    import re
    distributions = []
    with open(filepath, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    header_seen = False
    for line in lines:
        line = line.strip()
        if not line:
            continue
        # 检测表头（包含 datasize 或 countScan 等关键词）
        if not header_seen and ('datasize' in line.lower() or 'countscan' in line.lower()):
            header_seen = True
            continue
        # 跳过汇总行（以 totalSize 开头）
        if line.lower().startswith('totalsize'):
            continue
        if not header_seen:
            continue

        parts = line.split('\t')
        if len(parts) < 4:
            continue
        try:
            datasize = int(parts[0])
            count_scan = int(parts[1])
            count_noscan = int(parts[2])
            total_bytes = int(parts[3])
            total_count = count_scan + count_noscan
            if total_count > 0:
                distributions.append(SizeDistribution(
                    size=datasize, count=total_count, total_bytes=total_bytes
                ))
        except (ValueError, IndexError) as e:
            print(f"  警告: 跳过无法解析的行: {line[:80]}... ({e})", file=sys.stderr)
            continue
    return distributions


class SizeDistribution:
    def __init__(self, size: int, count: int, total_bytes: int):
        self.size = size
        self.count = count
        self.total_bytes = total_bytes

    def __repr__(self):
        return f"SizeDistribution(size={self.size}, count={self.count}, total_bytes={self.total_bytes})"


# ── 规则检查 ─────────────────────────────────────────────

def check_rule1(size: int, npages: int) -> Tuple[bool, int, int]:
    """规则1: (allocsize % size) ≤ allocsize ÷ 8"""
    allocsize = PAGE_SIZE * npages
    remainder = allocsize % size
    threshold = allocsize // 8
    return (remainder <= threshold, remainder, threshold)


def check_rule2(size: int, npages: int) -> Tuple[bool, int]:
    """规则2: size ≥ new_size (其中 new_size = (allocsize // (allocsize // size)) & ~127)"""
    if size == 0:
        return (True, 0)
    allocsize = PAGE_SIZE * npages
    div = allocsize // size
    if div == 0:
        return (False, 0)
    temp = allocsize // div
    new_size = temp & (~127)
    return (size >= new_size, new_size)

def check_rule3(npages: int) -> Tuple[bool, int, int]:
    """规则1: (allocsize % size) ≤ allocsize ÷ 8"""
    return (PAGE_SIZE * npages) % 65536 == 0

@lru_cache(maxsize=4096)
def find_valid_pages(size: int) -> int:
    """为给定 size 找到满足规则1和规则2的最优 pages（带缓存）"""
    if size == 0:
        return 0

    # 动态确定 pages 搜索上限
    # 保守估计：每个 page=8192B，至少装 1 个对象
    max_pages = max(8, (size // PAGE_SIZE) + 2)
    # 大对象最多搜到合理上限
    max_pages = min(max_pages, 64)

    for pages in range(1, max_pages + 1):
        r1_pass, _, _ = check_rule1(size, pages)
        r2_pass, _ = check_rule2(size, pages)
        if r1_pass and r2_pass and check_rule3(pages):
            return pages
    return -1


@lru_cache(maxsize=4096)
def is_valid_size(size: int) -> bool:
    """检查 size 是否合法（带缓存）"""
    if size == 0:
        return True
    if size % 8 != 0:
        return False
    return find_valid_pages(size) != -1


# ── 候选生成 ─────────────────────────────────────────────

def generate_candidates_by_range() -> Dict[str, List[int]]:
    """按区间和步长生成候选 sizes，并补入业务高频 size"""
    small = []   # 8B ~ 1KB
    medium = []  # 1KB ~ 8KB
    large = []   # 8KB ~ 32KB

    # 小对象: 8B~128B (8B步长)
    for size in range(8, SMALL_STEP_8B_END + 1, 8):
        if is_valid_size(size):
            small.append(size)
    # 128B~512B (16B步长)
    for size in range(SMALL_STEP_8B_END + 16, SMALL_STEP_16B_END + 1, 16):
        if is_valid_size(size):
            small.append(size)
    # 512B~1024B (32B步长)
    for size in range(SMALL_STEP_16B_END + 32, SMALL_STEP_32B_END + 1, 32):
        if is_valid_size(size):
            small.append(size)

    # 中对象: 1024B~8192B (128B步长)，从 1024 之后开始填补空窗
    # 先补 1024~1152 之间的过渡 (64B步长)
    for size in range(1024 + 64, 1152 + 1, 64):
        if is_valid_size(size):
            medium.append(size)
    # 1152~8192 (128B步长)
    for size in range(1152, MEDIUM_END + 1, MEDIUM_STEP):
        if is_valid_size(size):
            medium.append(size)

    # 大对象: 8192B~32768B (256B步长)，从 >8192 开始
    # 8192 归入中对象，大对象从 8192+256 开始
    for size in range(MEDIUM_END + LARGE_STEP, LARGE_END + 1, LARGE_STEP):
        if is_valid_size(size):
            large.append(size)
    # 确保 32768 在列表中
    if 32768 not in large:
        large.append(32768)

    # 去重排序
    small = sorted(set(small))
    medium = sorted(set(medium))
    large = sorted(set(large))
    print(f"  small: {len(small)} 个")
    print(f"  medium: {len(medium)} 个")
    print(f"  large: {len(large)} 个")

    return {'small': small, 'medium': medium, 'large': large}


def align_up_8(size: int) -> int:
    """向上对齐到 8 的倍数"""
    return ((size + 7) // 8) * 8


def add_business_sizes_to_candidates(
    candidates: Dict[str, List[int]],
    distributions: List[SizeDistribution],
    top_n: int = 30
) -> Dict[str, List[int]]:
    """
    从业务数据中提取高频对象尺寸，对齐后补入候选池。
    top_n: 每个区间最多补入的数量。
    """
    # 按 count 排序取 top 对象尺寸
    sorted_dists = sorted(distributions, key=lambda d: d.count, reverse=True)

    def classify_size(sz: int) -> str:
        if sz <= 1024:
            return 'small'
        elif sz <= MEDIUM_END:
            return 'medium'
        else:
            return 'large'

    added = {'small': 0, 'medium': 0, 'large': 0}
    existing = set()
    for zone in ['small', 'medium', 'large']:
        for s in candidates[zone]:
            existing.add(s)

    for dist in sorted_dists:
        aligned = align_up_8(dist.size)
        if aligned == 0:
            continue
        zone = classify_size(aligned)
        if zone == 'small' and aligned > 1024:
            zone = 'medium'
        if zone == 'medium' and aligned > MEDIUM_END:
            zone = 'large'
        if aligned > LARGE_END:
            continue  # 超出范围
        if added[zone] >= top_n:
            continue
        if aligned in existing:
            continue
        if not is_valid_size(aligned):
            continue
        candidates[zone].append(aligned)
        existing.add(aligned)
        added[zone] += 1

    for zone in ['small', 'medium', 'large']:
        candidates[zone] = sorted(set(candidates[zone]))
    return candidates


# ── 密度选优算法 ─────────────────────────────────────────

def calc_density_scores(candidates: List[int], distributions: List[SizeDistribution]) -> Dict[int, float]:
    """
    基于"区间内对象密度"计算每个候选的价值。
    对每个候选 size c[i]，统计对象大小落在 (c[i-1], c[i]] 区间的总字节数。
    这准确反映了该候选作为 class 时覆盖的实际分配量。
    """
    # 构建对象 size -> count 映射
    size_count = {}
    size_total_size = {}
    for dist in distributions:
        size_count[dist.size] = size_count.get(dist.size, 0) + dist.count


    scores = {}
    prev = 0
    for cand in candidates:
        total_count = 0
        # 统计 (prev, cand] 范围内的对象
        for obj_size, cnt in size_count.items():
            if prev < obj_size <= cand:
                total_count += cnt
        # 使用 count 加权（也可以加入字节数作为辅助权重）
        scores[cand] = float(total_count)
        prev = cand

    return scores


def select_optimal_classes(
    distributions: List[SizeDistribution],
    target_total: int = TARGET_COUNT
) -> List[int]:
    """按区间配比 + 密度打分选择最优的 size classes"""

    # ── 强制包含的 size ──
    sc = []
    for i in range(SMALL_SIZE_MAX // SMALL_SIZE_DIV + 1):
        sc.append(i * SMALL_SIZE_DIV)

    for i in range((MAX_SMALL_SIZE-SMALL_SIZE_MAX) // LARGE_SIZE_DIV + 1):
        sc.append(SMALL_SIZE_MAX + i * LARGE_SIZE_DIV)

    # 生成候选并补入业务高频 size
    candidates = generate_candidates_by_range()
    candidates = add_business_sizes_to_candidates(candidates, distributions, top_n=30)

    small_cands = candidates['small']
    medium_cands = candidates['medium']
    large_cands = candidates['large']

    print(f"\n候选分布（含业务高频）:")
    print(f"  小对象候选: {len(small_cands)} 个")
    print(f"  中对象候选: {len(medium_cands)} 个")
    print(f"  大对象候选: {len(large_cands)} 个")

    # ── 辅助: 计算密度分数 ──
    small_scores = calc_density_scores(small_cands, distributions)
    medium_scores = calc_density_scores(medium_cands, distributions)
    large_scores = calc_density_scores(large_cands, distributions)

    # ── 选择小对象 ──
    small_selected = set()
    for m in MANDATORY_SMALL:
        if m in small_cands:
            small_selected.add(m)

    # 按密度排序，选满上限
    small_ranked = sorted(small_cands, key=lambda s: small_scores.get(s, 0), reverse=True)
    for s in small_ranked:
        if len(small_selected) >= ZONE_LIMITS['small']:
            break
        small_selected.add(s)
    small_selected = sorted(small_selected)

    # ── 选择中对象 ──
    medium_selected = set()
    medium_ranked = sorted(medium_cands, key=lambda s: medium_scores.get(s, 0), reverse=True)
    for s in medium_ranked:
        if len(medium_selected) >= ZONE_LIMITS['medium']:
            break
        medium_selected.add(s)
    medium_selected = sorted(medium_selected)

    # ── 选择大对象 ──
    large_selected = set()
    if 32768 in large_cands:
        large_selected.add(32768)
    large_ranked = sorted(large_cands, key=lambda s: large_scores.get(s, 0), reverse=True)
    for s in large_ranked:
        if len(large_selected) >= ZONE_LIMITS['large']:
            break
        large_selected.add(s)
    large_selected = sorted(large_selected)

    # ── 合并 ──
    selected = [0] + small_selected + medium_selected + large_selected
    selected = sorted(set(selected))

    print(f"\n初步选择结果:")
    print(f"  小对象: {len(small_selected)} 个 (上限{ZONE_LIMITS['small']})")
    print(f"  中对象: {len(medium_selected)} 个 (上限{ZONE_LIMITS['medium']})")
    print(f"  大对象: {len(large_selected)} 个 (上限{ZONE_LIMITS['large']})")
    print(f"  总计: {len(selected)} 个 (含class 0)")

    # ── 调整到恰好 target_total ──
    needed = target_total - len(selected)

    if needed != 0:
        # 汇总所有剩余候选的分数
        all_remaining = []
        for s in small_cands + medium_cands + large_cands:
            if s not in selected:
                score = small_scores.get(s) or medium_scores.get(s) or large_scores.get(s, 0)
                all_remaining.append((s, score))
        all_remaining.sort(key=lambda x: x[1], reverse=True)
        
        # 构建字典供后续使用
        all_remaining_dict = {s: score for s, score in all_remaining}

        if needed > 0:
            for s, _ in all_remaining:
                if needed <= 0:
                    break
                selected.append(s)
                needed -= 1
        elif needed < 0:
            # 需要削减 — 从非强制项中移除密度最低的
            for _ in range(-needed):
                removable = [(s, all_remaining_dict.get(s, 0))
                             for s in selected
                             if s != 0 and s not in MANDATORY_SMALL and s not in MANDATORY_LARGE]
                if not removable:
                    break
                removable.sort(key=lambda x: x[1])
                selected.remove(removable[0][0])

    selected = sorted(set(selected))

    # 如果还是不够，放宽区间上限补充
    if len(selected) < target_total:
        print(f"  警告: 候选不足({len(selected)}/{target_total})，放宽区间限制补充...")
        # 尝试在候选池中按密度继续补
        needed = target_total - len(selected)
        for s, _ in all_remaining:
            if needed <= 0:
                break
            if s not in selected:
                selected.append(s)
                needed -= 1
    selected = sorted(set(selected))

    # 检查是否需要削减超出目标
    while len(selected) > target_total:
        # 按密度移除最低的非强制项
        min_score = float('inf')
        remove_s = None
        for s in selected:
            if s == 0 or s in MANDATORY_SMALL or s in MANDATORY_LARGE:
                continue
            score = small_scores.get(s) or medium_scores.get(s) or large_scores.get(s, 0)
            if score < min_score:
                min_score = score
                remove_s = s
        if remove_s is not None:
            selected.remove(remove_s)
        else:
            break
    selected = sorted(set(selected))

    print(f"\n最终选择结果:")
    print(f"  小对象: {sum(1 for s in selected if 8 <= s <= 1024)} 个 (上限{ZONE_LIMITS['small']})")
    print(f"  中对象: {sum(1 for s in selected if 1024 < s <= MEDIUM_END)} 个 (上限{ZONE_LIMITS['medium']})")
    print(f"  大对象: {sum(1 for s in selected if s > MEDIUM_END)} 个 (上限{ZONE_LIMITS['large']})")
    print(f"  总计: {len(selected)} 个 (含class 0)")

    return selected


# ── 校验 ─────────────────────────────────────────────────

def validate_size_classes(size_classes: List[Tuple[int, int]]) -> Tuple[bool, List[str]]:
    """校验逻辑: 总数68、对齐、递增、边界值、规则1/2、区间配比"""
    errors = []

    if len(size_classes) != TARGET_COUNT:
        errors.append(f"错误: size class 数量 = {len(size_classes)}, 必须为 {TARGET_COUNT}")

    if size_classes[0][0] != 0:
        errors.append(f"错误: class 0 size = {size_classes[0][0]}, 必须为 0")
    if size_classes[0][1] != 0:
        errors.append(f"错误: class 0 pages = {size_classes[0][1]}, 必须为 0")
    if size_classes[-1][0] != 32768:
        errors.append(f"错误: class 67 size = {size_classes[-1][0]}, 必须为 32768")

    small_count = sum(1 for s, _ in size_classes if 8 <= s <= 1024)
    medium_count = sum(1 for s, _ in size_classes if 1024 < s <= MEDIUM_END)
    large_count = sum(1 for s, _ in size_classes if s > MEDIUM_END)

    if small_count > ZONE_LIMITS['small']:
        errors.append(f"错误: 小对象数量 = {small_count}, 上限{ZONE_LIMITS['small']}")
    if medium_count > ZONE_LIMITS['medium']:
        errors.append(f"错误: 中对象数量 = {medium_count}, 上限{ZONE_LIMITS['medium']}")
    if large_count > ZONE_LIMITS['large']:
        errors.append(f"错误: 大对象数量 = {large_count}, 上限{ZONE_LIMITS['large']}")
    if large_count < 3:
        errors.append(f"警告: 大对象数量 = {large_count}, 建议至少保留3个")

    for i, (size, pages) in enumerate(size_classes):
        if size == 0:
            continue
        if size % 8 != 0:
            errors.append(f"错误: class {i} size={size}, 不是8的倍数")

        r1_pass, rem, thresh = check_rule1(size, pages)
        if not r1_pass:
            errors.append(f"错误: class {i} size={size} pages={pages}, 规则1失败: {rem} > {thresh}")

        r2_pass, new_size = check_rule2(size, pages)
        if not r2_pass:
            errors.append(f"错误: class {i} size={size} pages={pages}, 规则2失败: {size} < {new_size}")

        if i > 0:
            if size <= size_classes[i - 1][0]:
                errors.append(f"错误: class {i} size={size} <= class {i - 1} size={size_classes[i - 1][0]}")

    sizes = [sc[0] for sc in size_classes]
    if 16 not in sizes:
        errors.append("错误: 缺少 16B tiny 对象规格")

    return len(errors) == 0, errors


# ── 生成与输出 ───────────────────────────────────────────

def generate_size_classes(
    distributions: List[SizeDistribution],
    target_count: int = TARGET_COUNT
) -> List[Tuple[int, int]]:
    """主函数: 选择 size 并计算 pages"""
    selected = select_optimal_classes(distributions, target_total=target_count)

    result = []
    for size in selected:
        pages = find_valid_pages(size)
        result.append((size, pages))
    return result


def calculate_total_waste(
    distributions: List[SizeDistribution],
    size_classes: List[Tuple[int, int]]
) -> Tuple[float, int, int]:
    """
    计算浪费率。
    Returns: (waste_rate, total_allocated, total_needed)
      - total_allocated: 分配器实际分配的字节数（含浪费）
      - total_needed:    业务对象实际需要的字节数
      - waste_rate:      浪费比例
    """
    sizes = [sc[0] for sc in size_classes]
    total_allocated = 0  # 分配量（= 对象数 × class size）
    total_needed = 0      # 需求量（= 对象数 × 对象 size）

    for dist in distributions:
        class_size = None
        for sc in sizes:
            if sc >= dist.size:
                class_size = sc
                break
        if class_size is None:
            class_size = dist.size
        total_allocated += dist.count * class_size
        total_needed += dist.count * dist.size

    waste_rate = (total_allocated - total_needed) / total_allocated if total_allocated > 0 else 0
    return waste_rate, total_allocated, total_needed


def print_analysis(distributions: List[SizeDistribution], size_classes: List[Tuple[int, int]]):
    waste_rate, total_allocated, total_needed = calculate_total_waste(distributions, size_classes)

    small_count = sum(1 for s, _ in size_classes if 8 <= s <= 1024)
    medium_count = sum(1 for s, _ in size_classes if 1024 < s <= MEDIUM_END)
    large_count = sum(1 for s, _ in size_classes if s > MEDIUM_END)

    print("\n" + "=" * 90)
    print("Size Class 分析报告")
    print("=" * 90)
    print(f"\n总对象类型数: {len(distributions)}")
    print(f"Size Class 数量: {len(size_classes)}")
    print(f"区间分布:")
    print(f"  小对象 (8B~1KB):  {small_count} 个 (上限{ZONE_LIMITS['small']})")
    print(f"  中对象 (1KB~8KB): {medium_count} 个 (上限{ZONE_LIMITS['medium']})")
    print(f"  大对象 (8KB~32KB):{large_count} 个 (上限{ZONE_LIMITS['large']})")
    print(f"业务实际需求: {total_needed:,} bytes ({total_needed / 1024 / 1024:.2f} MB)")
    print(f"分配器分配量: {total_allocated:,} bytes ({total_allocated / 1024 / 1024:.2f} MB)")
    print(f"内存浪费量:   {total_allocated - total_needed:,} bytes ({(total_allocated - total_needed) / 1024 / 1024:.2f} MB)")
    print(f"整体浪费率:   {waste_rate * 100:.2f}%")

    print(f"\n{'Index':<8} | {'Size':<10} | {'Pages':<8} | {'区间':<8} | {'规则1':<20} | {'规则2':<20}")
    print("-" * 90)

    for i, (size, pages) in enumerate(size_classes):
        if size == 0:
            print(f"{i:<8} | {size:<10} | {pages:<8} | {'N/A':<8} | {'N/A':<20} | {'N/A':<20}")
        else:
            if size <= 1024:
                range_str = "小"
            elif size <= MEDIUM_END:
                range_str = "中"
            else:
                range_str = "大"

            allocsize = pages * PAGE_SIZE
            r1_pass, rem, thresh = check_rule1(size, pages)
            r1_str = f"{'OK' if r1_pass else 'FAIL'} {rem}<={thresh}"
            r2_pass, new_size = check_rule2(size, pages)
            r2_str = f"{'OK' if r2_pass else 'FAIL'} {size}>={new_size}"
            print(f"{i:<8} | {size:<10} | {pages:<8} | {range_str:<8} | {r1_str:<20} | {r2_str:<20}")


def write_output(filepath: str, size_classes: List[Tuple[int, int]]):
    with open(filepath, 'w', encoding='utf-8') as f:
        for size, pages in size_classes:
            f.write(f"{size},{pages}\n")
    print(f"\n已写入文件: {filepath}")
    print(f"  共 {len(size_classes)} 行")


# ── 入口 ─────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='Go Size Class 优化生成器 — 基于业务对象分布生成最优 span sizeclass 配置'
    )
    parser.add_argument(
        '-i', '--input',
        default='datasize_10.txt',
        help='业务对象大小分布数据文件 (默认: datasize_20.txt)'
    )
    parser.add_argument(
        '-o', '--output',
        default='go_sizeclasses_optimized.txt',
        help='输出配置文件路径 (默认: go_sizeclasses_optimized.txt)'
    )

    args = parser.parse_args()

    input_file = Path(args.input)
    output_file = Path(args.output)

    if not input_file.exists():
        print(f"错误: 输入文件不存在: {input_file}", file=sys.stderr)
        sys.exit(1)

    print("=" * 90)
    print("Go Size Class 优化生成器 (按区间配比 + 密度选优)")
    print("=" * 90)

    print(f"\n输入文件: {input_file}")
    print(f"输出文件: {output_file}")
    print(f"目标数量: {TARGET_COUNT} (固定)")

    print("\n正在解析数据文件...")
    distributions = parse_datasize_file(str(input_file))
    print(f"找到 {len(distributions)} 种不同大小的对象")

    if len(distributions) == 0:
        print("错误: 未解析到任何有效数据", file=sys.stderr)
        sys.exit(1)

    print("\n正在生成优化的 size class...")
    size_classes = generate_size_classes(distributions, target_count=TARGET_COUNT)

    print("\n正在校验...")
    is_valid, errors = validate_size_classes(size_classes)

    if is_valid:
        print("校验通过!")
    else:
        print("校验失败:")
        for err in errors:
            print(f"  {err}")
        sys.exit(1)

    print_analysis(distributions, size_classes)
    write_output(str(output_file), size_classes)

    print("\n完成!")


if __name__ == '__main__':
    main()
