// bench_alloc - 模拟常见业务场景的分配压力测试
//
// 场景设计：
//   - 全局缓存：map 存储"用户会话"（长期对象，模拟全局状态）
//   - 请求处理：每 50µs 一个请求，分配请求结构体、临时 buffer、响应体
//   - 后台任务：定时清理过期会话、聚合统计
//   - GC 日志：GODEBUG=gctrace=1 运行
//
// 用法：
//   GODEBUG=gctrace=1 go run bench_alloc.go
//   运行 5 分钟后自动退出，输出统计摘要

package main

import (
	"fmt"
	"math/rand"
	"os"
	"runtime"
	"sync"
	"sync/atomic"
	"time"
)

const (
	runDuration  = 5 * time.Minute
	reqInterval  = 50 * time.Microsecond // 每 50µs 一个请求，约 2 万 QPS
	cleanupEvery = 10 * time.Second
	maxSessions  = 50000 // 全局缓存最多保留的会话数
)

// ---------------------------------------------------------------------------
// 全局状态（不会被 GC 回收的长期对象）
// ---------------------------------------------------------------------------

var (
	globalSessions sync.Map // key: int64 sessionID → *Session

	// 全局计数器
	totalRequests   atomic.Int64
	totalAllocs     atomic.Int64
	totalBytes      atomic.Int64
	activeSessions  atomic.Int64
)

// Session 模拟用户会话 - 包含多种大小的字段
type Session struct {
	ID        int64
	UserID    int64
	UserName  string       // 10-50 字节
	Token     string       // 32 字节
	Roles     []string     // 动态数量
	Metadata  map[string]string
	LoginAt   time.Time
	LastSeen  time.Time
	RequestIDs []int64     // 最近 100 个请求 ID
	RawData   []byte       // 0-8KB 的会话数据
}

// Request 模拟业务请求
type Request struct {
	ID        int64
	SessionID int64
	Path      string       // URL 路径
	Method    string       // HTTP 方法
	Headers   map[string]string
	Body      []byte       // 请求体，256B-16KB
}

// Response 模拟响应
type Response struct {
	RequestID int64
	Status    int
	Body      []byte       // 响应体，64B-32KB
	Headers   map[string]string
}

// ---------------------------------------------------------------------------
// 分配模式定义（模拟真实业务大小分布）
// ---------------------------------------------------------------------------

// 对象大小分布（对齐 Go 常见分配模式）:
//   30% →   1-16 字节  (tiny objects: strings, small slices)
//   25% →  17-64  字节  (structs, small maps)
//   20% →  65-256 字节  (medium structs)
//   15% → 257-1024 字节  (buffers, slices)
//    8% → 1025-4096 字节  (large buffers)
//    2% → 4097-32768 字节 (very large objects)

func randomSize() int {
	r := rand.Float64()
	switch {
	case r < 0.30:
		return 1 + rand.Intn(16)
	case r < 0.55:
		return 17 + rand.Intn(48)
	case r < 0.75:
		return 65 + rand.Intn(192)
	case r < 0.90:
		return 257 + rand.Intn(768)
	case r < 0.98:
		return 1025 + rand.Intn(3072)
	default:
		return 4097 + rand.Intn(28672)
	}
}

// randomBytes 生成指定长度的随机字节切片
func randomBytes(n int) []byte {
	b := make([]byte, n)
	// 写入一些非零数据避免完全零值
	for i := range b {
		if rand.Intn(4) == 0 {
			b[i] = byte(rand.Intn(256))
		}
	}
	return b
}

// randomString 生成随机字符串
func randomString(n int) string {
	const letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	b := make([]byte, n)
	for i := range b {
		b[i] = letters[rand.Intn(len(letters))]
	}
	return string(b)
}

// ---------------------------------------------------------------------------
// 业务逻辑
// ---------------------------------------------------------------------------

// handleRequest 模拟处理一个请求
func handleRequest(sessionID int64) {
	req := &Request{
		ID:        totalRequests.Add(1),
		SessionID: sessionID,
		Path:      randomPath(),
		Method:    randomMethod(),
		Headers:   randomHeaders(),
		Body:      randomBytes(randomSize()),
	}

	// 模拟业务处理: 查数据库、计算、构建响应
	_ = processRequest(req)

	// 响应 (有时很大)
	resp := buildResponse(req)

	// 模拟写入日志
	_ = fmt.Sprintf("req=%d session=%d path=%s status=%d bodyLen=%d",
		req.ID, req.SessionID, req.Path, resp.Status, len(resp.Body))

	// 记录统计（更新全局原子变量）

	totalBytes.Add(int64(len(req.Body) + len(resp.Body)))
	totalAllocs.Add(4) // req + resp + body + headers ≈
}

func randomPath() string {
	paths := []string{
		"/api/users", "/api/orders", "/api/products", "/api/search",
		"/api/auth/login", "/api/auth/refresh", "/api/cart", "/api/checkout",
		"/health", "/metrics", "/api/notifications", "/api/settings",
	}
	return paths[rand.Intn(len(paths))]
}

func randomMethod() string {
	methods := []string{"GET", "POST", "PUT", "DELETE"}
	return methods[rand.Intn(len(methods))]
}

func randomHeaders() map[string]string {
	n := rand.Intn(10)
	h := make(map[string]string, n)
	for i := 0; i < n; i++ {
		h[randomString(rand.Intn(20)+5)] = randomString(rand.Intn(50)+5)
	}
	return h
}

func processRequest(req *Request) error {
	// 模拟业务处理：一些临时分配
	_ = make([]byte, rand.Intn(1024)+64)  // 临时 buffer
	_ = make([]int, rand.Intn(100)+10)    // 临时 slice
	_ = map[string]int{randomString(8): 1, randomString(8): 2} // 临时 map
	return nil
}

func buildResponse(req *Request) *Response {
	return &Response{
		RequestID: req.ID,
		Status:    200,
		Body:      randomBytes(randomSize()),
		Headers:   randomHeaders(),
	}
}

// createSession 创建新会话（全局对象）
func createSession(id int64) *Session {
	s := &Session{
		ID:      id,
		UserID:  rand.Int63n(1000000),
		UserName: randomString(rand.Intn(40) + 10),
		Token:    randomString(32),
		Roles:    randomRoles(),
		Metadata: map[string]string{
			"ip":       fmt.Sprintf("%d.%d.%d.%d", rand.Intn(256), rand.Intn(256), rand.Intn(256), rand.Intn(256)),
			"browser":  randomString(rand.Intn(20) + 5),
			"platform": randomString(rand.Intn(10) + 3),
		},
		LoginAt:  time.Now(),
		LastSeen: time.Now(),
		RawData:  randomBytes(rand.Intn(8192)),
	}
	s.RequestIDs = make([]int64, 0, 100)
	activeSessions.Add(1)
	return s
}

func randomRoles() []string {
	n := rand.Intn(5) + 1
	roles := make([]string, n)
	allRoles := []string{"admin", "user", "viewer", "editor", "manager", "auditor", "api"}
	for i := range roles {
		roles[i] = allRoles[rand.Intn(len(allRoles))]
	}
	return roles
}

// cleanupSessions 清理过期会话（产生可回收垃圾）
func cleanupSessions() {
	var toDelete []int64
	cutoff := time.Now().Add(-30 * time.Second)

	globalSessions.Range(func(key, value any) bool {
		id := key.(int64)
		s := value.(*Session)
		if s.LastSeen.Before(cutoff) {
			toDelete = append(toDelete, id)
		}
		return true
	})

	for _, id := range toDelete {
		globalSessions.Delete(id)
		activeSessions.Add(-1)
	}
}

// getOrCreateSession 获取或创建会话
func getOrCreateSession(id int64) *Session {
	if s, ok := globalSessions.Load(id); ok {
		sess := s.(*Session)
		sess.LastSeen = time.Now()
		return sess
	}

	// 限制全局会话数量
	if count := activeSessions.Load(); count >= maxSessions {
		return nil
	}

	sess := createSession(id)
	globalSessions.Store(id, sess)
	return sess
}

// ---------------------------------------------------------------------------
// 主循环
// ---------------------------------------------------------------------------

func main() {
	fmt.Println("=== Go Size Class Bench ===")
	fmt.Printf("Duration: %v | Request interval: %v | Max sessions: %d\n", runDuration, reqInterval, maxSessions)
	fmt.Printf("GOMAXPROCS: %d | GOGC: %s\n", runtime.GOMAXPROCS(0), os.Getenv("GOGC"))
	fmt.Println()

	// 初始化一些全局会话
	for i := 0; i < 10000; i++ {
		id := rand.Int63n(10000000)
		sess := createSession(id)
		globalSessions.Store(id, sess)
	}

	// 启动后台清理
	go func() {
		ticker := time.NewTicker(cleanupEvery)
		defer ticker.Stop()
		for range ticker.C {
			cleanupSessions()
		}
	}()

	// 启动工作协程（模拟并发请求处理）
	var wg sync.WaitGroup
	numWorkers := runtime.GOMAXPROCS(0) * 2
	stopCh := make(chan struct{})

	for w := 0; w < numWorkers; w++ {
		wg.Add(1)
		go func(workerID int) {
			defer wg.Done()
			ticker := time.NewTicker(reqInterval)
			defer ticker.Stop()
			for {
				select {
				case <-stopCh:
					return
				case <-ticker.C:
					sessionID := rand.Int63n(10000000)
					_ = getOrCreateSession(sessionID)
					handleRequest(sessionID)
				}
			}
		}(w)
	}

	// 启动统计输出
	go func() {
		ticker := time.NewTicker(30 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			var m runtime.MemStats
			runtime.ReadMemStats(&m)
			fmt.Printf("[%s] reqs=%d allocs=%d heap=%.0fMB gc=%d pause=%.2fms sessions=%d\n",
				time.Now().Format("15:04:05"),
				totalRequests.Load(),
				totalAllocs.Load(),
				float64(m.HeapAlloc)/(1024*1024),
				m.NumGC,
				float64(m.PauseTotalNs)/(1e6),
				activeSessions.Load(),
			)
		}
	}()

	// 运行指定时长
	fmt.Printf("Running for %v...\n\n", runDuration)
	time.Sleep(runDuration)

	// 停止
	close(stopCh)
	wg.Wait()

	// 最终统计
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	fmt.Println()
	fmt.Println("========================================")
	fmt.Println("  最终统计")
	fmt.Println("========================================")
	fmt.Printf("  总请求:        %d\n", totalRequests.Load())
	fmt.Printf("  总分配:        %d\n", totalAllocs.Load())
	fmt.Printf("  总字节:        %.0f MB\n", float64(totalBytes.Load())/(1024*1024))
	fmt.Printf("  HeapAlloc:     %.0f MB\n", float64(m.HeapAlloc)/(1024*1024))
	fmt.Printf("  HeapSys:       %.0f MB\n", float64(m.HeapSys)/(1024*1024))
	fmt.Printf("  HeapInuse:     %.0f MB\n", float64(m.HeapInuse)/(1024*1024))
	fmt.Printf("  HeapIdle:      %.0f MB\n", float64(m.HeapIdle)/(1024*1024))
	fmt.Printf("  StackInuse:    %.0f MB\n", float64(m.StackInuse)/(1024*1024))
	fmt.Printf("  MSpanInuse:    %.0f MB\n", float64(m.MSpanInuse)/(1024*1024))
	fmt.Printf("  MCacheInuse:   %.0f MB\n", float64(m.MCacheInuse)/(1024*1024))
	fmt.Printf("  NumGC:         %d\n", m.NumGC)
	fmt.Printf("  TotalPause:    %.2f ms\n", float64(m.PauseTotalNs)/(1e6))
	fmt.Printf("  GCCPUFraction: %.2f%%\n", m.GCCPUFraction*100)
	fmt.Printf("  活跃会话:       %d\n", activeSessions.Load())
	fmt.Println("========================================")
}
