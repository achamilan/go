# Go Memory Size Class 优化设计文档

## 1. 背景

Go runtime 的内存分配器为 ≤32KB 的小对象使用 size class 机制：对象按实际大小 `s` 映射到满足 `classSize ≥ s` 的最小 class，分配器以 span（npages × 8KB）为单位向操作系统申请内存，span 被等分为 classSize 大小的槽位。

默认 size class 配置（`mksizeclasses.go` 生成）是通过固定间距公式产生的通用解，未针对特定业务负载优化。本工作基于业务分配快照（`datasize.txt`），探索最小化内存浪费的 size class 配置。

## 2. 浪费模型

### 2.1 总浪费 = 内部碎片 + 外部碎片

**内部碎片（Internal Waste）：** 对象大小向上取整到 classSize 的差额。

```
internalWaste = Σ (classSize − actualSize) × objectCount
```

例：3 字节对象 → class 8，每对象浪费 5 字节。

**外部碎片（External Waste）：** span 尾部无法容纳完整对象的剩余空间。scan 和 noscan 对象分属不同 mcentral，span 独立计算。

```
spanSize      = npages × 8192
objPerSpan    = spanSize / classSize
spans         = ceil(objectCount / objPerSpan)
externalWaste = spans × spanSize − objectCount × classSize
```

**关键公式：**

每对象外部浪费 ≈ tailPerSpan / objPerSpan，仅取决于 span 几何，与 class 内具体 classSize 无关。对于同一 objPerSpan 区间内的不同 classSize，总浪费（内部+外部）恒定。

### 2.2 输入数据

| 数据集 | 独立 Size 数 | 总对象数 | 总实际字节 | Size 范围 |
|--------|:--------:|--------:|----------:|:-------:|
| datasize.txt | 12,573 | 31.2 亿 | 274 GB | 1–32760 |
| 0623/datasize06231148.txt | 5,521 | 82.6 亿 | 615 GB | 1–32760 |

数据格式（TSV）：`datasize` | `countScan` | `countNoscan` | `totalSize` | `elemsize` | `totalSizeAlign8`

## 3. 约束条件

| 约束 | 值 | 说明 |
|------|-----|------|
| align | 8 | classSize 必须 8 字节对齐 |
| nPageUnit | 8 | npages 必须是 8 的倍数（64KB 对齐，支持大页） |
| maxNPages | 16 | npages 上限（128KB span） |
| NumSizeClasses | 68 | 总 class 数上限（含 class 0） |
| maxSmallSize | 32768 | 最大小对象大小 |
| wasteLimit | 12.5% | span 尾部浪费不得超过 spanSize 的 1/8 |

**determineNPages 算法：**

```go
func determineNPages(classSize int) int {
    unitSize := nPageUnit * 8192   // 起始分配大小
    for allocSize := unitSize; allocSize <= maxNPages * 8192; allocSize += unitSize {
        if allocSize % classSize <= allocSize / 8 {
            return allocSize / 8192  // 满足 12.5% 约束即返回
        }
    }
    return 0  // 约束内无解
}
```

此为最小满足约束的 npages，**非最优 npages**（见 §5.2 关键洞察）。

## 4. 优化算法

### 4.1 前缀和预处理

对分配数据按 size 排序后构建前缀和，实现 O(1) 的 class 浪费评估：

```go
type PrefixSums struct {
    ScanCount   []int64  // 前缀累计 scan 对象数
    NoscanCount []int64  // 前缀累计 noscan 对象数
    SizeByCount []int64  // 前缀累计 (size × count)
}
```

区间 [start, end] 内的 internalWaste 和 externalWaste 可由前缀和差分直接计算。

### 4.2 贪心拆分（Greedy Split）

```
1. 初始配置：[16, maxSmallSize]（2 个 class）
2. while len(classes) < target:
   a. 遍历每个 class，尝试在其覆盖的 size 区间内插入新 class
   b. 对每个候选对齐 classSize，计算拆分前后的浪费差值
   c. 选择减少浪费最多的拆分点
   d. 若无正向收益，终止
3. 返回 class 列表
```

### 4.3 局部调优（Local Refinement）

```go
for iter := 0; iter < 50; iter++ {
    for each class {
        // 尝试比当前 classSize 更小的对齐候选值
        for each aligned size in [prevClassSize+1, classSize) {
            if 满足 determineNPages {
                计算拆分后总浪费
                若比当前更好，更新 classSize 和 npages
            }
        }
    }
    if 本轮无改进 { break }
}
```

## 5. 关键洞察

### 5.1 classSize vs objPerSpan 的不变性

对于给定的 objPerSpan 区间，每对象总浪费（内部+外部）恒定，与具体 classSize 无关：

```
每对象分配字节 = spanSize / objPerSpan = 常数
每对象总浪费  = 分配字节 − 实际对象大小
```

因此，单纯在 objPerSpan 不变的区间内增加 class **不会减少总浪费**，只是把内部碎片转嫁为外部碎片（或反之）。

### 5.2 determineNPages 不是最优

`determineNPages` 返回**第一个**满足 12.5% 约束的 npages，但更大的 npages 可能实现更优的 objPerSpan，从而消除尾部浪费：

| ClassSize | determineNPages 结果 | 最优 npages | 最优的理由 |
|-----------|:------------------:|:----------:|-----------|
| 20480 | np=8 (o/s=3, tail=4096) | **np=40** (o/s=16, tail=0) | 16 对象/span，零尾部浪费 |
| 24576 | np=16 (o/s=5, tail=8192) | np=24 (o/s=8, tail=0) | 8 对象/span，零尾部浪费 |
| 24576 (max16) | np=16 (o/s=5, tail=8192) | **np=12** (o/s=4, tail=0)\* | 4 对象/span，零尾部浪费 |

\* 仅当 nPageUnit=4 时可用（12 页 = 96KB span）

### 5.3 为什么 npages=8 是最优默认

nPageUnit=4 虽然为 24576 提供 np=12 的完美适配，但整体效果更差：
- 小 class 被迫用 32KB span，span 数翻倍
- 每对象外部浪费不变（tail/objPerSpan 等比例缩放）
- 贪心拆分在 4× 搜索空间内收敛到更差的局部最优

**结论：nPageUnit=8 为最优。**

## 6. 优化结果

### 6.1 数据集 1（datasize.txt, 31.2 亿对象）

| 配置 | Span 分配 | 总浪费 | 效率 | 浪费率 |
|------|--------:|-----:|-----:|-----:|
| **optimized_v4** | 280.5 GB | **6.1 GB** | **97.83%** | **2.17%** |
| 8page_unit (v1) | 282.7 GB | 8.3 GB | 97.05% | 2.95% |
| round64k | 288.5 GB | 14.1 GB | 95.12% | 4.88% |
| Go 默认 | 289.8 GB | 15.4 GB | 94.68% | 5.32% |
| go_sizeclasses | 295.8 GB | 21.4 GB | 92.76% | 7.24% |

**相比 go_sizeclasses 减少浪费 71.5%（省 15.3 GB）。**

### 6.2 数据集 2（0623/datasize06231148.txt, 82.6 亿对象）

| 配置 | Span 分配 | 总浪费 | 效率 | 浪费率 |
|------|--------:|-----:|-----:|-----:|
| **optimized_v2** (np≤40) | 628 GB | **14.2 GB** | **97.89%** | **2.11%** |
| **optimized_max16_512** (np≤16) | 677 GB | **16.6 GB** | **97.54%** | **2.46%** |
| go_sizeclasses | 691 GB | 31.2 GB | 95.48% | 4.52% |
| Go 默认 | 701 GB | 40.8 GB | 94.18% | 5.82% |

**max16 约束相比 go_sizeclasses 仍减少浪费 46.8%（省 15.7 GB）。**

## 7. 最终推荐配置

### 7.1 npages ≤ 40（最优效果，97.89% 效率）

文件：`0623/optimized_v2.txt`

核心改动：class 20480 使用 **npages=40**（320KB span），16 对象/span，零尾部浪费。

```
# 上半部分与 optimized_max16_512 相同
...
16384,8
20480,40     ← 关键：40-page span，覆盖 1.65M 个 20408 字节对象
32768,8
```

### 7.2 npages ≤ 16（配合 512 约束，97.54% 效率）

文件：`0623/optimized_max16_512.txt`

```
0,0
8,8
16,8
24,8
32,8
40,8
48,8
56,8
64,8
72,8
80,8
88,8
96,8
104,8
112,8
120,8
128,8
136,8
144,8
152,8
160,8
168,8
176,8
192,8
200,8
224,8
240,8
256,8
272,8
288,8
304,8
328,8
352,8
376,8
408,8
464,8
512,8        ← 强制保留（Go runtime lookup table 边界）
520,8
568,8
616,8
648,8
736,8
768,8
784,8
872,8
960,8
1040,8
1144,8
1232,8
1320,8
1456,8
1544,8
1680,8
1752,8
1816,8
1920,8
2112,8
2424,8
2848,8
3264,8
3808,8
4672,8
6528,8
8192,8
10896,8
13104,8
21760,8      ← objPerSpan=3, 尾部仅 256B，覆盖 1.65M 个 20408 对象
32768,8      ← 终结 class（maxSmallSize）
```

## 8. 工具说明

| 工具 | 用法 | 功能 |
|------|------|------|
| `waste_analysis.go` | `go run waste_analysis.go [config] [data]` | 逐 class 浪费分析，生成报告+CSV |
| `waste_calc.go` | `go run waste_calc.go [config]` | 快速浪费计算 |
| `optimize.go` | `go run optimize.go [data]` | 贪心拆分+局部调优 |
| `obj_to_sizeclass.go` | `go run obj_to_sizeclass.go` | 按 alignment class 聚合统计 |

## 9. 已知局限

1. **静态快照偏差**：分析基于分配快照，实际运行的稳态分布可能不同（GC 回收效应）。
2. **不包含大对象（>32KB）**：大对象走独立分配路径，不在 size class 优化范围内。
3. **determineNPages 次优**：贪心返回最小满足约束的 npages，未搜索全局最优 npages。
4. **贪心局部最优**：贪心拆分不能保证全局最优 class 组合。
5. **模型不包含 span 元数据、mcentral、mcache 等运行时开销**。
6. **单负载标定**：优化结果针对特定业务的分配特征，通用性需要多负载验证。
