// waste_calc - Memory waste calculator for Go size class optimization.
//
// Usage: go run waste_calc.go [sizeclass_file]
//
// If no file is specified, reads "go_sizeclasses" by default.
//
// Reads datasize.txt (business object allocation statistics) and
// the size class table, then computes:
//   - Internal waste: (classSize - actualSize) per object (round-up)
//   - External waste: unused tail bytes per span (page chopping)
//
// Scan and noscan spans are calculated separately since they use
// different mcentral pools in the Go runtime.

package main

import (
	"bufio"
	"fmt"
	"math"
	"os"
	"sort"
	"strconv"
	"strings"
)

const pageSize = 8192

// Default Go size classes for comparison.
var defaultClasses = []SizeClass{
	{Index: 0, ClassSize: 0, NPages: 0},
	{Index: 1, ClassSize: 8, NPages: 1},
	{Index: 2, ClassSize: 16, NPages: 1},
	{Index: 3, ClassSize: 24, NPages: 1},
	{Index: 4, ClassSize: 32, NPages: 1},
	{Index: 5, ClassSize: 48, NPages: 1},
	{Index: 6, ClassSize: 64, NPages: 1},
	{Index: 7, ClassSize: 80, NPages: 1},
	{Index: 8, ClassSize: 96, NPages: 1},
	{Index: 9, ClassSize: 112, NPages: 1},
	{Index: 10, ClassSize: 128, NPages: 1},
	{Index: 11, ClassSize: 144, NPages: 1},
	{Index: 12, ClassSize: 160, NPages: 1},
	{Index: 13, ClassSize: 176, NPages: 1},
	{Index: 14, ClassSize: 192, NPages: 1},
	{Index: 15, ClassSize: 208, NPages: 1},
	{Index: 16, ClassSize: 224, NPages: 1},
	{Index: 17, ClassSize: 240, NPages: 1},
	{Index: 18, ClassSize: 256, NPages: 1},
	{Index: 19, ClassSize: 288, NPages: 1},
	{Index: 20, ClassSize: 320, NPages: 1},
	{Index: 21, ClassSize: 352, NPages: 1},
	{Index: 22, ClassSize: 384, NPages: 1},
	{Index: 23, ClassSize: 416, NPages: 1},
	{Index: 24, ClassSize: 448, NPages: 1},
	{Index: 25, ClassSize: 480, NPages: 1},
	{Index: 26, ClassSize: 512, NPages: 1},
	{Index: 27, ClassSize: 576, NPages: 1},
	{Index: 28, ClassSize: 640, NPages: 1},
	{Index: 29, ClassSize: 704, NPages: 1},
	{Index: 30, ClassSize: 768, NPages: 1},
	{Index: 31, ClassSize: 896, NPages: 1},
	{Index: 32, ClassSize: 1024, NPages: 1},
	{Index: 33, ClassSize: 1152, NPages: 1},
	{Index: 34, ClassSize: 1280, NPages: 1},
	{Index: 35, ClassSize: 1408, NPages: 2},
	{Index: 36, ClassSize: 1536, NPages: 1},
	{Index: 37, ClassSize: 1792, NPages: 2},
	{Index: 38, ClassSize: 2048, NPages: 1},
	{Index: 39, ClassSize: 2304, NPages: 2},
	{Index: 40, ClassSize: 2688, NPages: 1},
	{Index: 41, ClassSize: 3072, NPages: 3},
	{Index: 42, ClassSize: 3200, NPages: 2},
	{Index: 43, ClassSize: 3456, NPages: 3},
	{Index: 44, ClassSize: 4096, NPages: 1},
	{Index: 45, ClassSize: 4864, NPages: 3},
	{Index: 46, ClassSize: 5376, NPages: 2},
	{Index: 47, ClassSize: 6144, NPages: 3},
	{Index: 48, ClassSize: 6528, NPages: 4},
	{Index: 49, ClassSize: 6784, NPages: 5},
	{Index: 50, ClassSize: 6912, NPages: 6},
	{Index: 51, ClassSize: 8192, NPages: 1},
	{Index: 52, ClassSize: 9472, NPages: 7},
	{Index: 53, ClassSize: 9728, NPages: 6},
	{Index: 54, ClassSize: 10240, NPages: 5},
	{Index: 55, ClassSize: 10880, NPages: 4},
	{Index: 56, ClassSize: 12288, NPages: 3},
	{Index: 57, ClassSize: 13568, NPages: 5},
	{Index: 58, ClassSize: 14336, NPages: 7},
	{Index: 59, ClassSize: 16384, NPages: 2},
	{Index: 60, ClassSize: 18432, NPages: 9},
	{Index: 61, ClassSize: 19072, NPages: 7},
	{Index: 62, ClassSize: 20480, NPages: 5},
	{Index: 63, ClassSize: 21760, NPages: 8},
	{Index: 64, ClassSize: 24576, NPages: 3},
	{Index: 65, ClassSize: 27264, NPages: 10},
	{Index: 66, ClassSize: 28672, NPages: 7},
	{Index: 67, ClassSize: 32768, NPages: 4},
}

// SizeClass represents one entry in the size class table.
type SizeClass struct {
	Index      int
	ClassSize  int
	NPages     int
	SpanSize   int // NPages * pageSize
	ObjPerSpan int // SpanSize / ClassSize
}

// DataRow represents one row from datasize.txt.
type DataRow struct {
	DataSize        int
	CountScan       int64
	CountNoscan     int64
	TotalCount      int64
	TotalSizeBytes  int64
	ElemSize        int
	TotalSizeAlign8 int64
}

// ClassAggregation holds aggregated statistics for one size class.
type ClassAggregation struct {
	Class       SizeClass
	MinSize     int
	MaxSize     int
	ScanCount   int64
	NoscanCount int64
	TotalCount  int64
	// Internal waste: (classSize - actualSize) summed across all objects
	InternalWaste int64
	// Spans needed for scan and noscan separately
	ScanSpans   int64
	NoscanSpans int64
	// External waste: unused tail bytes
	ScanExternalWaste   int64
	NoscanExternalWaste int64
	// Total memory allocated (span bytes)
	ScanSpanBytes   int64
	NoscanSpanBytes int64
	// Sizes grouped into this class
	SizeCount int
}

func main() {
	classFile := "go_sizeclasses"
	if len(os.Args) > 1 {
		classFile = os.Args[1]
	}

	// Parse data (shared across both comparisons)
	rows := parseDataSizes("datasize.txt")
	fmt.Printf("Loaded %d data rows\n", len(rows))

	// 1. Analyze with custom size classes
	classes := parseSizeClasses(classFile)
	fmt.Printf("\n=== Custom size classes from %s ===\n", classFile)
	fmt.Printf("Loaded %d size classes (excluding dummy 0)\n", len(classes)-1)
	agg := aggregate(classes, rows)
	printReport(agg, rows, classes)

	// 2. Compare with Go defaults
	fmt.Println()
	fmt.Println()
	initDefaultClasses()
	fmt.Println("=== Go default size classes for comparison ===")
	fmt.Printf("Loaded %d size classes (excluding dummy 0)\n", len(defaultClasses)-1)
	defaultAgg := aggregate(defaultClasses, rows)
	printReport(defaultAgg, rows, defaultClasses)
}

func initDefaultClasses() {
	for i := range defaultClasses {
		c := &defaultClasses[i]
		c.SpanSize = c.NPages * pageSize
		if c.ClassSize > 0 {
			c.ObjPerSpan = c.SpanSize / c.ClassSize
		}
	}
}

func parseSizeClasses(filename string) []SizeClass {
	f, err := os.Open(filename)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error opening %s: %v\n", filename, err)
		os.Exit(1)
	}
	defer f.Close()

	var classes []SizeClass
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		parts := strings.Split(line, ",")
		if len(parts) != 2 {
			continue
		}
		size, _ := strconv.Atoi(strings.TrimSpace(parts[0]))
		npages, _ := strconv.Atoi(strings.TrimSpace(parts[1]))
		spanSize := npages * pageSize
		objPerSpan := 0
		if size > 0 {
			objPerSpan = spanSize / size
		}
		classes = append(classes, SizeClass{
			Index:      len(classes),
			ClassSize:  size,
			NPages:     npages,
			SpanSize:   spanSize,
			ObjPerSpan: objPerSpan,
		})
	}
	return classes
}

func parseDataSizes(filename string) []DataRow {
	f, err := os.Open(filename)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error opening %s: %v\n", filename, err)
		os.Exit(1)
	}
	defer f.Close()

	var rows []DataRow
	sc := bufio.NewScanner(f)
	headerParsed := false
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		// Skip the totalSize summary line and header
		if strings.HasPrefix(line, "totalSize=") {
			continue
		}
		if !headerParsed {
			headerParsed = true
			continue
		}

		parts := strings.Split(line, "\t")
		if len(parts) < 6 {
			continue
		}
		dataSize, _ := strconv.Atoi(strings.TrimSpace(parts[0]))
		countScan, _ := strconv.ParseInt(strings.TrimSpace(parts[1]), 10, 64)
		countNoscan, _ := strconv.ParseInt(strings.TrimSpace(parts[2]), 10, 64)
		totalSize, _ := strconv.ParseInt(strings.TrimSpace(parts[3]), 10, 64)
		elemSize, _ := strconv.Atoi(strings.TrimSpace(parts[4]))
		totalSizeAlign8, _ := strconv.ParseInt(strings.TrimSpace(parts[5]), 10, 64)

		rows = append(rows, DataRow{
			DataSize:        dataSize,
			CountScan:       countScan,
			CountNoscan:     countNoscan,
			TotalCount:      countScan + countNoscan,
			TotalSizeBytes:  totalSize,
			ElemSize:        elemSize,
			TotalSizeAlign8: totalSizeAlign8,
		})
	}
	return rows
}

func findSizeClass(size int, classes []SizeClass) *SizeClass {
	// Skip class 0 (dummy). Find first class where ClassSize >= size.
	for i := 1; i < len(classes); i++ {
		if classes[i].ClassSize >= size {
			return &classes[i]
		}
	}
	// If size exceeds all classes, use the largest.
	return &classes[len(classes)-1]
}

func aggregate(classes []SizeClass, rows []DataRow) map[int]*ClassAggregation {
	result := make(map[int]*ClassAggregation)

	// Initialize all classes
	for i := 1; i < len(classes); i++ {
		c := classes[i]
		result[i] = &ClassAggregation{
			Class:   c,
			MinSize: int(math.MaxInt32),
			MaxSize: 0,
		}
	}

	unmapped := 0
	for _, row := range rows {
		if row.TotalCount == 0 {
			continue
		}
		sc := findSizeClass(row.DataSize, classes)
		if sc == nil || sc.Index == 0 {
			unmapped++
			continue
		}

		agg := result[sc.Index]
		agg.ScanCount += row.CountScan
		agg.NoscanCount += row.CountNoscan
		agg.TotalCount += row.TotalCount
		agg.SizeCount++

		if row.DataSize < agg.MinSize {
			agg.MinSize = row.DataSize
		}
		if row.DataSize > agg.MaxSize {
			agg.MaxSize = row.DataSize
		}

		// Internal waste per object = classSize - actualSize
		if row.CountScan > 0 {
			agg.InternalWaste += int64(sc.ClassSize-row.DataSize) * row.CountScan
		}
		if row.CountNoscan > 0 {
			agg.InternalWaste += int64(sc.ClassSize-row.DataSize) * row.CountNoscan
		}
	}

	// Calculate spans and external waste
	for i := range result {
		agg := result[i]
		c := agg.Class
		if c.ObjPerSpan == 0 {
			continue
		}

		// Scan spans
		if agg.ScanCount > 0 {
			agg.ScanSpans = (agg.ScanCount + int64(c.ObjPerSpan) - 1) / int64(c.ObjPerSpan)
			agg.ScanSpanBytes = agg.ScanSpans * int64(c.SpanSize)
			agg.ScanExternalWaste = agg.ScanSpanBytes - agg.ScanCount*int64(c.ClassSize)
		}

		// Noscan spans
		if agg.NoscanCount > 0 {
			agg.NoscanSpans = (agg.NoscanCount + int64(c.ObjPerSpan) - 1) / int64(c.ObjPerSpan)
			agg.NoscanSpanBytes = agg.NoscanSpans * int64(c.SpanSize)
			agg.NoscanExternalWaste = agg.NoscanSpanBytes - agg.NoscanCount*int64(c.ClassSize)
		}
	}

	return result
}

func printReport(agg map[int]*ClassAggregation, rows []DataRow, classes []SizeClass) {
	// Sort class indices
	var indices []int
	for i := range agg {
		indices = append(indices, i)
	}
	sort.Ints(indices)

	fmt.Println()
	fmt.Println(strings.Repeat("=", 140))
	fmt.Println("Per-Class Waste Analysis")
	fmt.Println(strings.Repeat("=", 140))
	fmt.Printf("%-5s %-10s %-6s %-7s %-12s %-12s %-14s %-14s %-14s %-14s %-14s\n",
		"Idx", "ClassSize", "Pages", "Obj/Span",
		"ScanCnt", "NoscanCnt",
		"IntWaste(B)", "ScanSpan", "NoscanSpan",
		"ScanExtWaste", "NoscanExtWaste")
	fmt.Println(strings.Repeat("-", 140))

	var totalInternalWaste int64
	var totalScanExternalWaste int64
	var totalNoscanExternalWaste int64
	var totalScanSpanBytes int64
	var totalNoscanSpanBytes int64
	var totalObjCount int64
	var totalScanObj int64
	var totalNoscanObj int64

	for _, i := range indices {
		a := agg[i]
		c := a.Class
		if a.TotalCount == 0 {
			continue
		}
		fmt.Printf("%-5d %-10d %-6d %-7d %-12d %-12d %-14d %-14d %-14d %-14d %-14d\n",
			c.Index, c.ClassSize, c.NPages, c.ObjPerSpan,
			a.ScanCount, a.NoscanCount,
			a.InternalWaste,
			a.ScanSpans, a.NoscanSpans,
			a.ScanExternalWaste, a.NoscanExternalWaste)

		totalInternalWaste += a.InternalWaste
		totalScanExternalWaste += a.ScanExternalWaste
		totalNoscanExternalWaste += a.NoscanExternalWaste
		totalScanSpanBytes += a.ScanSpanBytes
		totalNoscanSpanBytes += a.NoscanSpanBytes
		totalScanObj += a.ScanCount
		totalNoscanObj += a.NoscanCount
	}
	totalObjCount = totalScanObj + totalNoscanObj

	// Also compute total actual bytes used from raw data
	var totalActualBytes int64
	for _, row := range rows {
		if row.TotalCount > 0 {
			totalActualBytes += row.TotalSizeBytes
		}
	}

	totalExternalWaste := totalScanExternalWaste + totalNoscanExternalWaste
	totalSpanBytes := totalScanSpanBytes + totalNoscanSpanBytes
	totalWaste := totalInternalWaste + totalExternalWaste
	totalSpanBytesAll := totalSpanBytes // same

	fmt.Println(strings.Repeat("-", 140))

	// Size range per class
	fmt.Println()
	fmt.Printf("%-5s %-10s %-10s %-12s %-12s %-10s\n",
		"Idx", "ClassSize", "MinSize", "MaxSize", "ObjCount", "SizesIn")
	fmt.Println(strings.Repeat("-", 60))
	for _, i := range indices {
		a := agg[i]
		if a.TotalCount == 0 {
			continue
		}
		fmt.Printf("%-5d %-10d %-10d %-12d %-12d %-10d\n",
			a.Class.Index, a.Class.ClassSize, a.MinSize, a.MaxSize,
			a.TotalCount, a.SizeCount)
	}
	fmt.Println(strings.Repeat("-", 60))

	// Summary
	fmt.Println()
	fmt.Println(strings.Repeat("=", 80))
	fmt.Println("SUMMARY")
	fmt.Println(strings.Repeat("=", 80))
	fmt.Printf("Total objects:            %d (scan=%d, noscan=%d)\n",
		totalObjCount, totalScanObj, totalNoscanObj)
	fmt.Printf("Total actual bytes:       %d (%.2f MB)\n",
		totalActualBytes, float64(totalActualBytes)/(1024*1024))
	fmt.Printf("Total span bytes:         %d (%.2f MB)\n",
		totalSpanBytesAll, float64(totalSpanBytesAll)/(1024*1024))
	fmt.Println()
	fmt.Printf("Internal waste (roundup): %d (%.2f MB)\n",
		totalInternalWaste, float64(totalInternalWaste)/(1024*1024))
	fmt.Printf("External waste (tail):    %d (%.2f MB)\n",
		totalExternalWaste, float64(totalExternalWaste)/(1024*1024))
	fmt.Printf("  - Scan spans:            %d (%.2f MB)\n",
		totalScanExternalWaste, float64(totalScanExternalWaste)/(1024*1024))
	fmt.Printf("  - Noscan spans:          %d (%.2f MB)\n",
		totalNoscanExternalWaste, float64(totalNoscanExternalWaste)/(1024*1024))
	fmt.Printf("Total waste:              %d (%.2f MB)\n",
		totalWaste, float64(totalWaste)/(1024*1024))
	fmt.Println()
	wasteRatio := float64(totalWaste) / float64(totalSpanBytesAll) * 100
	actualRatio := float64(totalActualBytes) / float64(totalSpanBytesAll) * 100
	fmt.Printf("Memory efficiency:        %.2f%% (actual/total span)\n", actualRatio)
	fmt.Printf("Waste ratio:              %.2f%% (waste/total span)\n", wasteRatio)
	fmt.Println(strings.Repeat("=", 80))
}
