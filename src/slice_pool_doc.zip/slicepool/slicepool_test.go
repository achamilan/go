// Copyright 2025 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package slicepool_test

import (
	"fmt"
	"runtime"
	"sync"
	"testing"

	"slicepool"
)

func newBytePool() *slicepool.SlicePool[byte] {
	return &slicepool.SlicePool[byte]{
		New: func(n int) []byte { return make([]byte, n) },
	}
}

func TestBasic(t *testing.T) {
	pool := newBytePool()

	s1 := pool.Get(1024)
	if cap(s1) < 1024 {
		t.Fatalf("Get(1024) returned cap=%d, want >= 1024", cap(s1))
	}
	pool.Put(s1)

	s2 := pool.Get(1024)
	if cap(s2) < 1024 {
		t.Fatalf("second Get(1024) returned cap=%d, want >= 1024", cap(s2))
	}
	pool.Put(s2)
}

func TestPutGetSameClass(t *testing.T) {
	pool := newBytePool()

	orig := pool.Get(1024)
	pool.Put(orig)

	got := pool.Get(1024)
	if cap(got) != cap(orig) {
		t.Fatalf("expected cap=%d, got cap=%d", cap(orig), cap(got))
	}
}

func TestNewNil(t *testing.T) {
	pool := &slicepool.SlicePool[byte]{}

	s := pool.Get(1024)
	if s != nil {
		t.Fatal("Get with nil New should return nil when pool is empty")
	}
}

func TestConcurrent(t *testing.T) {
	pool := newBytePool()

	var wg sync.WaitGroup
	n := 100
	errCh := make(chan error, n*1000)
	for i := 0; i < n; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := 0; j < 1000; j++ {
				req := j%4096 + 16
				s := pool.Get(req)
				if cap(s) < req {
					errCh <- fmt.Errorf("Get(%d) returned cap=%d", req, cap(s))
					return
				}
				pool.Put(s)
			}
		}()
	}
	wg.Wait()
	close(errCh)
	for err := range errCh {
		t.Error(err)
	}
}

func TestPutNil(t *testing.T) {
	pool := newBytePool()
	pool.Put(nil) // should not panic
}

func TestGetZero(t *testing.T) {
	pool := newBytePool()
	s := pool.Get(0)
	if cap(s) < 1 {
		t.Fatal("Get(0) should return cap >= 1")
	}
}

func TestReuseAcrossSizes(t *testing.T) {
	pool := newBytePool()

	for _, sz := range []int{16, 32, 64, 128, 256, 512, 1024, 2048} {
		s := pool.Get(sz)
		if cap(s) < sz {
			t.Fatalf("Get(%d) returned cap=%d", sz, cap(s))
		}
		pool.Put(s)
	}
}

func TestPutSmallDiscarded(t *testing.T) {
	pool := newBytePool()
	pool.Put(make([]byte, 8)) // cap < 16, silently discarded
}

func TestPutMismatchedCapDiscarded(t *testing.T) {
	// Use New that returns a recognizable capacity so we can tell
	// whether Get hit the cache or allocated fresh.
	var called int
	pool := &slicepool.SlicePool[byte]{
		New: func(n int) []byte {
			called++
			return make([]byte, n)
		},
	}

	// Put a slice with cap that is not a class max.
	// cap=1024, class=6, classMax(6)=2047. 1024 != 2047 → discarded.
	pool.Put(make([]byte, 1024))

	// Get should allocate new, not use the discarded slice.
	s := pool.Get(1024)
	if cap(s) < 1024 {
		t.Fatalf("Get(1024) returned cap=%d", cap(s))
	}
	if called != 1 {
		t.Fatalf("New called %d times, want 1 (mismatched Put should be discarded)", called)
	}
}

func TestGC(t *testing.T) {
	pool := newBytePool()

	// Put slices with class-max capacities (they will be accepted).
	// Get(1024) allocates classMax(6) = 2047.
	for i := 0; i < 100; i++ {
		pool.Put(make([]byte, 2047))
	}

	runtime.GC()

	s := pool.Get(1024)
	if cap(s) < 1024 {
		t.Fatal("Get after GC should still work")
	}
}

func TestPutGetRepeatability(t *testing.T) {
	pool := newBytePool()

	// Get(500) allocates classMax(4) = 511. Put+Get should cycle in class 4.
	for i := 0; i < 10; i++ {
		s := pool.Get(500)
		if cap(s) < 500 {
			t.Fatalf("iteration %d: Get(500) returned cap=%d", i, cap(s))
		}
		pool.Put(s)
	}
}
