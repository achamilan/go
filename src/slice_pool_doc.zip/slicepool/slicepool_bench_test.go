// Copyright 2025 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package slicepool_test

import (
	"sync"
	"testing"

	"slicepool"
)

func BenchmarkMakeNew(b *testing.B) {
	for i := 0; i < b.N; i++ {
		s := make([]byte, 1024)
		_ = s
	}
}

func BenchmarkSyncPool(b *testing.B) {
	var pool = sync.Pool{
		New: func() any {
			return make([]byte, 1024)
		},
	}
	for i := 0; i < b.N; i++ {
		s := pool.Get().([]byte)
		pool.Put(s)
	}
}

func BenchmarkSlicePool(b *testing.B) {
	pool := slicepool.SlicePool[byte]{
		New: func(n int) []byte { return make([]byte, n) },
	}
	for i := 0; i < b.N; i++ {
		s := pool.Get(1024)
		pool.Put(s)
	}
}

func BenchmarkSlicePoolParallel(b *testing.B) {
	pool := slicepool.SlicePool[byte]{
		New: func(n int) []byte { return make([]byte, n) },
	}
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			s := pool.Get(1024)
			pool.Put(s)
		}
	})
}

func BenchmarkSyncPoolParallel(b *testing.B) {
	var pool = sync.Pool{
		New: func() any {
			return make([]byte, 1024)
		},
	}
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			s := pool.Get().([]byte)
			pool.Put(s)
		}
	})
}

func BenchmarkMixedSize(b *testing.B) {
	sizes := []int{256, 512, 1024, 2048, 4096, 8192}
	pool := slicepool.SlicePool[byte]{
		New: func(n int) []byte { return make([]byte, n) },
	}
	for i := 0; i < b.N; i++ {
		s := pool.Get(sizes[i%len(sizes)])
		pool.Put(s)
	}
}

func BenchmarkNetworkBuf(b *testing.B) {
	pool := slicepool.SlicePool[byte]{
		New: func(n int) []byte { return make([]byte, n) },
	}
	b.RunParallel(func(pb *testing.PB) {
		data := make([]byte, 1024)
		for pb.Next() {
			buf := pool.Get(4096)
			copy(buf, data)
			pool.Put(buf)
		}
	})
}
